import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home,
  BookOpen, 
  Activity, 
  BarChart3, 
  Trophy, 
  Settings,
  Menu,
  X,
  LogOut,
  Crown
} from 'lucide-react';
import AskApex from '@/components/chat/AskApex';
import LanguageSelector from '@/components/LanguageSelector';
import { getTranslation, getCurrentLanguage } from '@/components/utils/translations';

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const t = getTranslation(getCurrentLanguage());

  useEffect(() => {
    const checkAuth = async () => {
      const authed = await base44.auth.isAuthenticated();
      setIsAuthenticated(authed);
      if (authed) {
        const userData = await base44.auth.me();
        setUser(userData);
      }
    };
    checkAuth();
  }, []);

  // Landing page - no layout
  if (currentPageName === 'Landing') {
    return children;
  }

  // Not authenticated - redirect to landing
  if (!isAuthenticated && currentPageName !== 'Landing') {
    return (
      <div className="min-h-screen bg-[#121212] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-cyan-500/20 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Activity className="w-8 h-8 text-cyan-400" />
          </div>
          <p className="text-white/60">Chargement...</p>
        </div>
      </div>
    );
  }

  const navItems = [
    { name: t.nav.dashboard, icon: Home, page: 'Dashboard' },
    { name: t.nav.course, icon: BookOpen, page: 'Course' },
    { name: t.nav.analytics, icon: BarChart3, page: 'Analytics', pro: true },
    { name: t.nav.progress, icon: Trophy, page: 'Progress', pro: true },
    { name: 'Manage Content', icon: Settings, page: 'ManageContent' },
    { name: t.nav.settings, icon: Settings, page: 'Settings' }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex">
      {/* Desktop Sidebar - Logo + Nav */}
      <aside className="hidden lg:flex flex-col w-64 border-r border-white/10 bg-[#0a0a0a]">
        {/* Logo + Title */}
        <div className="p-6 border-b border-white/10">
          <Link to={createPageUrl('Dashboard')} className="flex items-center gap-3">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/694771cee5c3bdcbca49d1ba/3e8251a99_apexmainlogoright.png"
              alt="Full House GTO Logo"
              className="w-10 h-10 object-contain shrink-0"
            />
            <h1 className="text-lg font-normal text-white" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>Full House GTO</h1>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const isActive = currentPageName === item.page;
              return (
                <li key={item.name}>
                  <Link
                    to={createPageUrl(item.page)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      isActive
                        ? 'bg-[#00f5ff]/10 text-[#00f5ff]'
                        : 'text-white/60 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    <item.icon className="w-5 h-5" style={isActive ? { filter: 'drop-shadow(0 0 6px rgba(0, 245, 255, 0.4))' } : {}} />
                    <span className="font-medium">{item.name}</span>
                    {item.pro && (
                      <Crown className="w-3.5 h-3.5 text-amber-400 ml-auto" />
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* User & Language */}
        <div className="p-4 border-t border-white/10 space-y-3">
          <LanguageSelector />
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#00f5ff] to-purple-500 flex items-center justify-center text-white font-bold shrink-0">
              {user?.full_name?.charAt(0) || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">
                {user?.full_name || 'User'}
              </p>
              <p className="text-xs text-white/50 truncate">
                {user?.email}
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-gray-950/95 backdrop-blur-lg border-b border-white/10">
        <div className="flex items-center justify-between p-4 w-full">
          <Link to={createPageUrl('Dashboard')} className="flex items-center gap-2">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/694771cee5c3bdcbca49d1ba/3e8251a99_apexmainlogoright.png"
              alt="Full House GTO Logo"
              className="w-8 h-8 object-contain"
            />
            <span className="font-normal text-white">Full House GTO</span>
          </Link>
          <div className="flex items-center gap-2">
            <LanguageSelector />
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-lg hover:bg-white/10 text-white"
            >
              {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="lg:hidden fixed inset-0 bg-black/50 z-40"
              onClick={() => setIsSidebarOpen(false)}
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="lg:hidden fixed left-0 top-0 bottom-0 w-72 bg-gray-950 z-50 border-r border-white/10"
            >
              <div className="p-6 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/694771cee5c3bdcbca49d1ba/3e8251a99_apexmainlogoright.png"
                    alt="Full House GTO Logo"
                    className="w-10 h-10 object-contain"
                  />
                  <div>
                    <h1 className="font-normal text-white">Full House GTO</h1>
                    <p className="text-xs text-white/50">by Cintia Kimura</p>
                  </div>
                </div>
              </div>

              <nav className="p-4">
                <ul className="space-y-1">
                  {navItems.map((item) => {
                    const isActive = currentPageName === item.page;
                    return (
                      <li key={item.name}>
                        <Link
                          to={createPageUrl(item.page)}
                          onClick={() => setIsSidebarOpen(false)}
                          className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                            isActive
                              ? 'bg-cyan-500/20 text-cyan-400'
                              : 'text-white/60 hover:bg-white/5 hover:text-white'
                          }`}
                        >
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.name}</span>
                          {item.pro && (
                            <Crown className="w-3.5 h-3.5 text-amber-400 ml-auto" />
                          )}
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </nav>

              <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-white/10">
                <div className="flex items-center gap-3 px-4 py-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                    {user?.full_name?.charAt(0) || 'U'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">
                      {user?.full_name || 'User'}
                    </p>
                    <p className="text-xs text-white/50 truncate">
                      {user?.email}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => base44.auth.logout()}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10"
                >
                  <LogOut className="w-5 h-5" />
                  Log Out
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 lg:pt-0 pt-16 overflow-auto">
        {children}
      </main>

      {/* Ask Apex - Global Chat */}
      <AskApex />
    </div>
  );
}