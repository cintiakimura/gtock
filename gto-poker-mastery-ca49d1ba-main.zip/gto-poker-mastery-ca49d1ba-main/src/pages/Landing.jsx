import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { 
  Activity, 
  BookOpen, 
  BarChart3, 
  Trophy, 
  ChevronRight,
  Zap,
  Target,
  Shield,
  CheckCircle2,
  Play
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';

export default function Landing() {
  const features = [
    {
      icon: BookOpen,
      title: '15 Modules Pro',
      description: 'Des fondamentaux GTO au travail avancé avec les solveurs, enseigné par Cintia Kimura.'
    },
    {
      icon: Activity,
      title: 'Outil GTO Pulse',
      description: 'Analyse de mains en temps réel avec des cartes de statistiques déplaçables.'
    },
    {
      icon: BarChart3,
      title: 'Analytiques de Session',
      description: 'Suivez vos fuites, identifiez les patterns et obtenez des insights personnalisés.'
    },
    {
      icon: Trophy,
      title: 'Suivi de Progression',
      description: 'Gagnez des badges et suivez votre adhérence GTO au fil du temps.'
    }
  ];

  const tiers = [
    {
      name: 'GTO Pulse',
      price: '39,99€',
      period: '/mois',
      features: [
        'GTO Pulse (12 tables max)',
        'Analytiques & rapports de session',
        'Suivi de progression & badges',
        'IA de détection de fuites',
        'Insights personnalisés'
      ],
      cta: 'Commencer',
      highlighted: false,
      note: 'Outil en direct uniquement'
    },
    {
      name: 'Pro Mensuel',
      price: '59€',
      period: '/mois',
      features: [
        'Cours complet 15 modules',
        'GTO Pulse (12 tables max)',
        'Analytiques & rapports de session',
        'Suivi de progression & badges',
        'IA de détection de fuites',
        'Insights personnalisés'
      ],
      cta: 'Passer Pro',
      highlighted: true,
      note: 'Annulable à tout moment'
    },
    {
      name: 'Pro Lifetime',
      price: '399€',
      period: 'à vie',
      features: [
        'Cours complet 15 modules',
        'GTO Pulse (12 tables max)',
        'Analytiques & rapports de session',
        'Suivi de progression & badges',
        'IA de détection de fuites',
        'Accès à vie - un seul paiement'
      ],
      cta: 'Acheter Lifetime',
      highlighted: false,
      note: 'Remboursement sous 3 mois'
    }
  ];

  return (
    <div className="min-h-screen bg-[#121212] overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-6">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px]" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-[100px]" />
        </div>

        <div className="relative max-w-6xl mx-auto text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-8"
          >
            <Zap className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-cyan-400 font-medium">Maîtrisez la Stratégie GTO</span>
          </motion.div>

          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.05 }}
            className="mb-8"
          >
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/694771cee5c3bdcbca49d1ba/3e8251a99_apexmainlogoright.png"
              alt="Full House GTO Logo"
              className="w-32 h-32 mx-auto object-contain"
            />
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-normal text-white mb-6 tracking-tight"
          >
            Full House GTO
            <br />
            <span className="bg-gradient-to-r from-cyan-400 to-teal-400 bg-clip-text text-transparent">
              Maîtrise Complète du Poker
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-white/60 max-w-2xl mx-auto mb-10"
          >
            La plateforme complète par Cintia Kimura pour transformer votre jeu de poker. 
            Cours interactif, outil de décision GTO en direct et analytiques pour dominer les tables.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex items-center justify-center"
          >
            <Button 
              size="lg"
              onClick={() => base44.auth.redirectToLogin()}
              className="bg-gradient-to-r from-cyan-500 to-teal-500 hover:opacity-90 text-white font-semibold px-8 h-14 text-lg"
            >
              S'inscrire Maintenant
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </motion.div>

          {/* Hero Image/Demo */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-16 relative"
          >
            <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-gradient-to-b from-gray-900 to-gray-950 p-8">
              {/* Fake Dashboard Preview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Course Preview */}
                <div className="md:col-span-2 bg-white/5 rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <BookOpen className="w-5 h-5 text-cyan-400" />
                    <span className="text-white font-medium">Progression du Cours</span>
                  </div>
                  <div className="h-3 bg-white/10 rounded-full overflow-hidden mb-2">
                    <div className="h-full w-1/3 bg-gradient-to-r from-cyan-500 to-teal-500" />
                  </div>
                  <p className="text-white/40 text-sm">5 sur 15 modules terminés</p>
                </div>

                {/* GTO Card Preview */}
                <div className="bg-gradient-to-br from-green-900/40 to-green-950/60 rounded-xl p-4 border border-green-500/20 glow-premium">
                  <div className="text-xs text-white/60 mb-2">Table 1 — BTN</div>
                  <div className="text-4xl font-bold text-white mb-1">68%</div>
                  <div className="text-green-400 font-bold">RELANCE</div>
                  <div className="text-[10px] text-white/40">Main premium</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-6 bg-gradient-to-b from-transparent to-gray-900/50">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-normal text-white mb-4">
              Tout ce dont vous avez besoin pour gagner
            </h2>
            <p className="text-white/60 max-w-xl mx-auto">
              Un écosystème complet pour les joueurs de poker sérieux qui veulent maîtriser la stratégie GTO.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-6 rounded-2xl bg-gradient-to-br from-gray-900 to-gray-950 border border-white/10 hover:border-cyan-500/30 transition-colors group"
              >
                <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-4 group-hover:bg-cyan-500/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-cyan-400" />
                </div>
                <h3 className="text-lg font-normal text-white mb-2">{feature.title}</h3>
                <p className="text-white/50 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-normal text-white mb-4">
              Tarification Simple
            </h2>
            <p className="text-white/60">
              Commencez gratuitement, passez Pro quand vous êtes prêt à tout miser.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tiers.map((tier, index) => (
              <motion.div
                key={tier.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`
                  relative p-8 rounded-2xl border
                  ${tier.highlighted 
                    ? 'bg-gradient-to-br from-cyan-900/30 to-teal-900/30 border-cyan-500/30' 
                    : 'bg-gradient-to-br from-gray-900 to-gray-950 border-white/10'
                  }
                `}
              >
                {tier.highlighted && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-cyan-500 to-teal-500 rounded-full text-xs font-semibold text-white">
                    PLUS POPULAIRE
                  </div>
                )}

                <h3 className="text-xl font-normal text-white mb-2">{tier.name}</h3>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-4xl font-bold text-white">{tier.price}</span>
                  <span className="text-white/50">{tier.period}</span>
                </div>
                {tier.note && (
                  <p className="text-xs text-cyan-400 mb-4">{tier.note}</p>
                )}

                <ul className="space-y-3 mb-8">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3 text-white/70">
                      <CheckCircle2 className="w-5 h-5 text-teal-400 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Link to={createPageUrl('Dashboard')}>
                  <Button 
                    className={`
                      w-full h-12 font-semibold
                      ${tier.highlighted 
                        ? 'bg-gradient-to-r from-cyan-500 to-teal-500 hover:opacity-90' 
                        : 'bg-white/10 hover:bg-white/20'
                      }
                    `}
                  >
                    {tier.cta}
                  </Button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/10">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/694771cee5c3bdcbca49d1ba/3e8251a99_apexmainlogoright.png"
              alt="Full House GTO Logo"
              className="w-8 h-8 object-contain"
            />
            <span className="font-semibold text-white">Full House GTO</span>
          </div>
          <p className="text-white/40 text-sm">
            © 2025 Cintia Kimura. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  );
}