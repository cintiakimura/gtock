import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart3, 
  Calendar, 
  Download, 
  Lock,
  TrendingUp,
  Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProgressChart from '@/components/analytics/ProgressChart';
import LeakReport from '@/components/analytics/LeakReport';
import GTOLauncher from '@/components/gto/GTOLauncher';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function Analytics() {
  const [user, setUser] = useState(null);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: subscriptionData } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.Subscription.filter({ user_email: user.email });
      return results[0] || { tier: 'free' };
    },
    enabled: !!user?.email
  });

  const { data: sessions } = useQuery({
    queryKey: ['sessions', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.SessionData.filter({ user_email: user.email }, '-session_date', 30);
    },
    enabled: !!user?.email
  });

  const isPro = true; // Always show Pro features in preview

  const exportReport = () => {
    try {
      const report = `Full House GTO - Rapport de Session
========================
Generated: ${new Date().toLocaleDateString()}
Time Range: ${timeRange === '7d' ? 'Last 7 Days' : 'Last 30 Days'}

Summary:
- Total Hands: 1,520
- GTO Adherence: 76%
- Estimated Improvement: +2.4 bb/100

Top Leaks:
1. Overfolded BB defense vs BTN opens (-4.2 bb/100)
2. Under-bluffed river spots with blockers (-2.8 bb/100)
3. Called too wide OOP in 3-bet pots (-2.1 bb/100)

Insights:
- 3-bet more from BTN vs CO opens — villain folds 68%
- Increase probe bet frequency on wet turns
- Value bet thinner on paired boards

Keep grinding! 🎯`;

      const blob = new Blob([report], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `fullhouse-gto-report-${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-[#121212] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8"
        >
          <div>
            <div className="flex items-center gap-3 mb-2">
              <BarChart3 className="w-8 h-8 text-cyan-400" />
              <h1 className="text-3xl font-normal text-white">Analytics</h1>
            </div>
            <p className="text-white/60">
              Track your performance and identify leaks
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex bg-white/5 rounded-lg p-1">
              {['7d', '30d'].map((range) => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    timeRange === range
                      ? 'bg-cyan-500/20 text-cyan-400'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  {range === '7d' ? '7 Days' : '30 Days'}
                </button>
              ))}
            </div>
            <Button
              variant="outline"
              onClick={exportReport}
              className="border-white/20 text-white hover:bg-white/10"
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
        >
          {[
            { label: 'Total Sessions', value: '12', icon: Calendar, trend: '+3 this week' },
            { label: 'Hands Played', value: '1,520', icon: Activity, trend: '+280 today' },
            { label: 'GTO Adherence', value: '76%', icon: TrendingUp, trend: '+4% vs last week' },
            { label: 'Est. bb/100', value: '+2.4', icon: BarChart3, trend: 'Improving' }
          ].map((stat, index) => (
            <div 
              key={stat.label}
              className="p-5 rounded-2xl bg-gradient-to-br from-gray-900 to-gray-950 border border-white/10"
            >
              <div className="flex items-center justify-between mb-3">
                <stat.icon className="w-5 h-5 text-cyan-400" />
                <span className="text-xs text-teal-400">{stat.trend}</span>
              </div>
              <p className="text-white/50 text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
            </div>
          ))}
        </motion.div>

        {/* Charts & Reports */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ProgressChart data={[]} timeRange={timeRange} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <LeakReport leaks={[]} insights={[]} />
          </motion.div>
        </div>

        {/* End Session Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-8 text-center"
        >
          <Button
            size="lg"
            className="bg-gradient-to-r from-red-500 to-orange-500 hover:opacity-90"
          >
            End Current Session
          </Button>
          <p className="text-white/40 text-sm mt-2">
            Generate a detailed report for your current playing session
          </p>
        </motion.div>
      </div>

      <GTOLauncher isPro={isPro} />
    </div>
  );
}