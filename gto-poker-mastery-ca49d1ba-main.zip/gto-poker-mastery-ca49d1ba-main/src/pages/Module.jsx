import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import ReactMarkdown from 'react-markdown';
import { 
  ArrowLeft, 
  ArrowRight, 
  BookOpen, 
  Play, 
  CheckCircle2,
  Lock,
  Video,
  Activity,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MODULES, MODULE_CONTENT, QUIZZES } from '@/components/course/ModuleContent';
import Quiz from '@/components/course/Quiz';
import GTOLauncher from '@/components/gto/GTOLauncher';
import { getCurrentLanguage } from '@/components/utils/translations';

export default function ModulePage() {
  const urlParams = new URLSearchParams(window.location.search);
  const moduleId = parseInt(urlParams.get('id')) || 1;
  
  const [user, setUser] = useState(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [language, setLanguage] = useState(getCurrentLanguage());
  const queryClient = useQueryClient();

  // Re-import when language changes
  useEffect(() => {
    const handleStorageChange = () => {
      setLanguage(getCurrentLanguage());
      window.location.reload();
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const module = MODULES.find(m => m.id === moduleId);
  const content = MODULE_CONTENT[moduleId];
  const quiz = QUIZZES[moduleId];

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: progress } = useQuery({
    queryKey: ['courseProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.CourseProgress.filter({ user_email: user.email });
      return results[0] || { completed_modules: [], quiz_scores: {}, current_module: 1 };
    },
    enabled: !!user?.email
  });

  const { data: subscriptionData } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.Subscription.filter({ user_email: user.email });
      return results[0] || { tier: 'free' };
    },
    enabled: !!user?.email
  });

  const updateProgressMutation = useMutation({
    mutationFn: async (newProgress) => {
      if (progress?.id) {
        await base44.entities.CourseProgress.update(progress.id, newProgress);
      } else {
        await base44.entities.CourseProgress.create({
          user_email: user.email,
          ...newProgress
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['courseProgress']);
    }
  });

  const isPro = true; // Always show Pro features in preview
  const isLocked = !module?.free && !isPro;
  const isCompleted = progress?.completed_modules?.includes(moduleId);
  const completedModules = progress?.completed_modules || [];

  const handleQuizComplete = async (score) => {
    const newCompleted = [...completedModules];
    if (!newCompleted.includes(moduleId) && score >= 70) {
      newCompleted.push(moduleId);
    }
    
    const newScores = { ...(progress?.quiz_scores || {}), [moduleId]: score };
    const nextModule = Math.min(moduleId + 1, MODULES.length);

    await updateProgressMutation.mutateAsync({
      completed_modules: newCompleted,
      quiz_scores: newScores,
      current_module: nextModule,
      last_accessed: new Date().toISOString()
    });

    if (score >= 70) {
      setShowQuiz(false);
    }
  };

  const prevModule = moduleId > 1 ? MODULES[moduleId - 2] : null;
  const nextModule = moduleId < MODULES.length ? MODULES[moduleId] : null;

  if (isLocked) {
    return (
      <div className="min-h-screen bg-[#121212] flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md text-center"
        >
          <div className="w-20 h-20 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-6">
            <Lock className="w-10 h-10 text-amber-400" />
          </div>
          <h2 className="text-2xl font-normal text-white mb-4">Contenu Pro</h2>
          <p className="text-white/60 mb-8">
            Ce module fait partie du cours Pro. Passez Pro pour accéder aux 15 modules, 
            aux analytiques et aux fonctionnalités avancées.
          </p>
          <Link 
            to={createPageUrl('Settings')}
            className="inline-block px-8 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 text-white font-semibold hover:opacity-90"
          >
            Passer Pro — 59€/mois
          </Link>
        </motion.div>
        <GTOLauncher isPro={isPro} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#121212]">
      <div className="max-w-4xl mx-auto p-6">
        {/* Navigation */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <Link 
            to={createPageUrl('Course')}
            className="flex items-center gap-2 text-white/60 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Retour au Cours
          </Link>
          
          {isCompleted && (
            <div className="flex items-center gap-2 text-teal-400">
              <CheckCircle2 className="w-5 h-5" />
              <span className="text-sm font-medium">Terminé</span>
            </div>
          )}
        </motion.div>

        {/* Module Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-cyan-400" />
            </div>
            <div>
              <p className="text-sm text-cyan-400 font-medium">Module {moduleId}</p>
              <h1 className="text-2xl md:text-3xl font-normal text-white">{module?.title}</h1>
            </div>
          </div>
          <p className="text-white/60">{module?.description}</p>
        </motion.div>

        {/* Resources Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8 space-y-4"
        >
          {/* Video */}
          {(module?.[`video_${language}`] || module?.videoUrl) ? (
            <div className="rounded-2xl overflow-hidden bg-gradient-to-br from-gray-900 to-gray-950 border border-white/10">
              <video 
                controls 
                className="w-full aspect-video"
                src={module?.[`video_${language}`] || module?.videoUrl}
              >
                Votre navigateur ne supporte pas la vidéo.
              </video>
            </div>
          ) : (
            <div className="rounded-2xl overflow-hidden bg-gradient-to-br from-gray-900 to-gray-950 border border-white/10">
              <div className="aspect-video flex items-center justify-center bg-black/50">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4">
                    <Video className="w-8 h-8 text-white/60" />
                  </div>
                  <p className="text-white/60">{language === 'fr' ? 'Vidéo' : 'Video'}</p>
                  <p className="text-sm text-white/40">{language === 'fr' ? 'Bientôt disponible' : 'Coming soon'}</p>
                </div>
              </div>
            </div>
          )}

          {/* Additional Resources Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Podcast */}
            {module?.[`podcast_${language}`] ? (
              <a 
                href={module[`podcast_${language}`]}
                target="_blank"
                rel="noopener noreferrer"
                className="p-6 rounded-xl bg-gradient-to-br from-purple-900/20 to-purple-950/20 border border-purple-500/20 hover:border-purple-500/40 transition-all"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    <Activity className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">Podcast</p>
                    <p className="text-xs text-white/50">{language === 'fr' ? 'Écouter' : 'Listen'}</p>
                  </div>
                </div>
              </a>
            ) : (
              <div className="p-6 rounded-xl bg-gradient-to-br from-gray-900/50 to-gray-950/50 border border-white/10 opacity-50">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                    <Activity className="w-5 h-5 text-white/40" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white/60">Podcast</p>
                    <p className="text-xs text-white/40">{language === 'fr' ? 'Bientôt' : 'Soon'}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Slides */}
            {module?.[`slides_${language}`] ? (
              <a 
                href={module[`slides_${language}`]}
                target="_blank"
                rel="noopener noreferrer"
                className="p-6 rounded-xl bg-gradient-to-br from-cyan-900/20 to-cyan-950/20 border border-cyan-500/20 hover:border-cyan-500/40 transition-all"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">Slides</p>
                    <p className="text-xs text-white/50">{language === 'fr' ? 'Télécharger' : 'Download'}</p>
                  </div>
                </div>
              </a>
            ) : (
              <div className="p-6 rounded-xl bg-gradient-to-br from-gray-900/50 to-gray-950/50 border border-white/10 opacity-50">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-white/40" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white/60">Slides</p>
                    <p className="text-xs text-white/40">{language === 'fr' ? 'Bientôt' : 'Soon'}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Infographic */}
            {module?.[`infographic_${language}`] ? (
              <a 
                href={module[`infographic_${language}`]}
                target="_blank"
                rel="noopener noreferrer"
                className="p-6 rounded-xl bg-gradient-to-br from-amber-900/20 to-amber-950/20 border border-amber-500/20 hover:border-amber-500/40 transition-all"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
                    <BarChart3 className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">Infographie</p>
                    <p className="text-xs text-white/50">{language === 'fr' ? 'Voir' : 'View'}</p>
                  </div>
                </div>
              </a>
            ) : (
              <div className="p-6 rounded-xl bg-gradient-to-br from-gray-900/50 to-gray-950/50 border border-white/10 opacity-50">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                    <BarChart3 className="w-5 h-5 text-white/40" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white/60">{language === 'fr' ? 'Infographie' : 'Infographic'}</p>
                    <p className="text-xs text-white/40">{language === 'fr' ? 'Bientôt' : 'Soon'}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Content */}
        {!showQuiz ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="prose prose-invert max-w-none mb-12"
          >
            <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-8">
              <ReactMarkdown
                components={{
                  h1: ({ children }) => <h1 className="text-3xl font-normal text-white mb-6">{children}</h1>,
                  h2: ({ children }) => <h2 className="text-2xl font-normal text-white mt-8 mb-4">{children}</h2>,
                  h3: ({ children }) => <h3 className="text-xl font-normal text-white mt-6 mb-3">{children}</h3>,
                  p: ({ children }) => <p className="text-white/70 mb-4 leading-relaxed">{children}</p>,
                  ul: ({ children }) => <ul className="list-disc list-inside text-white/70 mb-4 space-y-2">{children}</ul>,
                  ol: ({ children }) => <ol className="list-decimal list-inside text-white/70 mb-4 space-y-2">{children}</ol>,
                  li: ({ children }) => <li className="text-white/70">{children}</li>,
                  strong: ({ children }) => <strong className="text-cyan-400 font-semibold">{children}</strong>,
                  table: ({ children }) => (
                    <div className="overflow-x-auto my-6">
                      <table className="w-full border-collapse">{children}</table>
                    </div>
                  ),
                  th: ({ children }) => <th className="border border-white/10 bg-white/5 px-4 py-2 text-left text-white font-semibold">{children}</th>,
                  td: ({ children }) => <td className="border border-white/10 px-4 py-2 text-white/70">{children}</td>,
                  blockquote: ({ children }) => (
                    <blockquote className="border-l-4 border-cyan-500 pl-4 my-4 text-white/60 italic">
                      {children}
                    </blockquote>
                  ),
                  code: ({ children }) => (
                    <code className="bg-white/10 px-2 py-1 rounded text-cyan-400 text-sm">{children}</code>
                  ),
                }}
              >
                {content || "Module content coming soon..."}
              </ReactMarkdown>
            </div>

            {/* Take Quiz Button */}
            {quiz && quiz.length > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-8 text-center"
              >
                <Button
                  onClick={() => setShowQuiz(true)}
                  className="bg-gradient-to-r from-cyan-500 to-teal-500 hover:opacity-90 px-8 h-12 text-lg"
                >
                  Passer le Quiz pour Terminer le Module
                </Button>
              </motion.div>
            )}
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Quiz
              questions={quiz}
              moduleId={moduleId}
              onComplete={handleQuizComplete}
            />
          </motion.div>
        )}

        {/* Navigation */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex items-center justify-between pt-8 border-t border-white/10"
        >
          {prevModule ? (
            <Link
              to={createPageUrl(`Module?id=${moduleId - 1}`)}
              className="flex items-center gap-2 text-white/60 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="hidden sm:inline">{prevModule.title}</span>
              <span className="sm:hidden">Précédent</span>
            </Link>
          ) : (
            <div />
          )}

          {nextModule && (
            <Link
              to={createPageUrl(`Module?id=${moduleId + 1}`)}
              className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <span className="hidden sm:inline">{nextModule.title}</span>
              <span className="sm:hidden">Suivant</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          )}
        </motion.div>
      </div>

      <GTOLauncher isPro={isPro} />
    </div>
  );
}