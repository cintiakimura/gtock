import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Video, Headphones, FileText, Image, Link as LinkIcon, Save, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MODULES } from '@/components/course/ModuleContent';

export default function ManageContent() {
  const [expandedModule, setExpandedModule] = useState(null);
  const [moduleAssets, setModuleAssets] = useState({});
  const [selectedLang, setSelectedLang] = useState('fr');

  const assetTypes = [
    { value: 'video', label: 'Video', icon: Video },
    { value: 'podcast', label: 'Podcast', icon: Headphones },
    { value: 'slides', label: 'Slides', icon: FileText },
    { value: 'infographic', label: 'Infographic', icon: Image },
    { value: 'other', label: 'Other', icon: LinkIcon }
  ];

  const addAsset = (moduleId, type) => {
    const key = `${moduleId}_${type}_${selectedLang}`;
    setModuleAssets({
      ...moduleAssets,
      [key]: moduleAssets[key] || ''
    });
  };

  const updateAssetUrl = (moduleId, type, url) => {
    const key = `${moduleId}_${type}_${selectedLang}`;
    setModuleAssets({
      ...moduleAssets,
      [key]: url
    });
  };

  const saveModuleAssets = (moduleId) => {
    console.log('Saving assets for module', moduleId, moduleAssets);
    alert(`Assets saved! Copy these values to ModuleContent.js:\n\n${JSON.stringify(
      Object.entries(moduleAssets)
        .filter(([key]) => key.startsWith(`${moduleId}_`))
        .reduce((acc, [key, value]) => {
          const [, type, lang] = key.split('_');
          acc[`${type}_${lang}`] = value;
          return acc;
        }, {}),
      null,
      2
    )}`);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-normal text-white mb-2" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
            Manage Course Content
          </h1>
          <p className="text-white/50">Add and manage video, podcast, slides, and infographic assets for each module</p>
        </div>

        {/* Language Selector */}
        <div className="mb-6 flex items-center gap-3">
          <span className="text-white/60 text-sm">Language:</span>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedLang('fr')}
              className={`px-4 py-2 rounded-lg transition-all ${
                selectedLang === 'fr'
                  ? 'bg-[#00f5ff] text-black font-medium'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              🇫🇷 Français
            </button>
            <button
              onClick={() => setSelectedLang('en')}
              className={`px-4 py-2 rounded-lg transition-all ${
                selectedLang === 'en'
                  ? 'bg-[#00f5ff] text-black font-medium'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              🇬🇧 English
            </button>
          </div>
        </div>

        {/* Modules List */}
        <div className="space-y-3">
          {MODULES.map((module) => {
            const isExpanded = expandedModule === module.id;
            
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: module.id * 0.05 }}
                className="bg-white/5 border border-white/10 rounded-xl overflow-hidden"
              >
                {/* Module Header */}
                <button
                  onClick={() => setExpandedModule(isExpanded ? null : module.id)}
                  className="w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#00f5ff]/20 flex items-center justify-center text-[#00f5ff] font-bold">
                      {module.id}
                    </div>
                    <div className="text-left">
                      <h3 className="text-white font-medium">{module.title}</h3>
                      <p className="text-white/50 text-sm">{module.description}</p>
                    </div>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-white/60" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-white/60" />
                  )}
                </button>

                {/* Module Content - Assets Management */}
                {isExpanded && (
                  <div className="p-4 border-t border-white/10 space-y-4">
                    {/* Asset Type Buttons */}
                    <div className="flex flex-wrap gap-2">
                      {assetTypes.map((type) => {
                        const Icon = type.icon;
                        const key = `${module.id}_${type.value}_${selectedLang}`;
                        const hasAsset = moduleAssets[key] !== undefined;
                        
                        return (
                          <button
                            key={type.value}
                            onClick={() => addAsset(module.id, type.value)}
                            className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
                              hasAsset
                                ? 'bg-[#00f5ff]/20 border border-[#00f5ff]/40 text-[#00f5ff]'
                                : 'bg-white/5 border border-white/10 text-white/60 hover:bg-white/10'
                            }`}
                          >
                            <Icon className="w-4 h-4" />
                            <span className="text-sm">{type.label}</span>
                            {!hasAsset && <Plus className="w-3 h-3" />}
                          </button>
                        );
                      })}
                    </div>

                    {/* Asset URL Inputs */}
                    <div className="space-y-3">
                      {assetTypes.map((type) => {
                        const key = `${module.id}_${type.value}_${selectedLang}`;
                        if (moduleAssets[key] === undefined) return null;

                        const Icon = type.icon;
                        
                        return (
                          <div key={key} className="flex items-center gap-3">
                            <div className="flex items-center gap-2 min-w-[140px]">
                              <Icon className="w-4 h-4 text-[#00f5ff]" />
                              <span className="text-white/60 text-sm">{type.label}</span>
                              <span className="text-white/40 text-xs">({selectedLang})</span>
                            </div>
                            <Input
                              type="url"
                              placeholder="Enter URL or file path"
                              value={moduleAssets[key] || ''}
                              onChange={(e) => updateAssetUrl(module.id, type.value, e.target.value)}
                              className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-white/30"
                            />
                            <button
                              onClick={() => {
                                const newAssets = { ...moduleAssets };
                                delete newAssets[key];
                                setModuleAssets(newAssets);
                              }}
                              className="text-red-400 hover:text-red-300 text-sm"
                            >
                              Remove
                            </button>
                          </div>
                        );
                      })}
                    </div>

                    {/* Save Button */}
                    {Object.keys(moduleAssets).some(k => k.startsWith(`${module.id}_`)) && (
                      <Button
                        onClick={() => saveModuleAssets(module.id)}
                        className="w-full bg-gradient-to-r from-[#00b3b3] to-[#00e5e5] hover:opacity-90 text-white font-medium"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save & Copy JSON for Module {module.id}
                      </Button>
                    )}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Instructions */}
        <div className="mt-8 p-4 bg-[#00f5ff]/10 border border-[#00f5ff]/20 rounded-xl">
          <h3 className="text-[#00f5ff] font-medium mb-2">How to use:</h3>
          <ol className="text-white/60 text-sm space-y-1 list-decimal list-inside">
            <li>Select language (French or English)</li>
            <li>Expand a module and click asset type buttons to add resources</li>
            <li>Enter URLs for each asset</li>
            <li>Click "Save & Copy JSON" to get the data structure</li>
            <li>Copy the JSON output and paste it into components/course/ModuleContent.js for that module</li>
            <li>Switch language and repeat for the other language's assets</li>
          </ol>
        </div>
      </div>
    </div>
  );
}