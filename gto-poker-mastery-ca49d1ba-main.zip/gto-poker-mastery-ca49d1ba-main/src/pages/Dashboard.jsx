import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  BookOpen, 
  Activity, 
  BarChart3, 
  Trophy,
  Lock,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MODULES } from '@/components/course/ModuleContent';
import GTOLauncher from '@/components/gto/GTOLauncher';
import SharkLogo from '@/components/branding/SharkLogo';
import { getTranslation, getCurrentLanguage } from '@/components/utils/translations';

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: progress } = useQuery({
    queryKey: ['courseProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.CourseProgress.filter({ user_email: user.email });
      return results[0] || { completed_modules: [], quiz_scores: {}, current_module: 1 };
    },
    enabled: !!user?.email
  });

  const { data: subscriptionData } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.Subscription.filter({ user_email: user.email });
      return results[0] || { tier: 'free' };
    },
    enabled: !!user?.email
  });

  const isPro = true; // Always show Pro features in preview
  const completedModules = progress?.completed_modules || [];
  const completionPercent = Math.round((completedModules.length / MODULES.length) * 100);
  const t = getTranslation(getCurrentLanguage());

  const hubCards = [
    {
      title: t.dashboard.courseCard.title,
      subtitle: t.dashboard.courseCard.subtitle,
      icon: BookOpen,
      iconColor: '#00f5ff',
      highlight: `${completedModules.length}/15 ${t.dashboard.courseCard.completed}`,
      button: t.dashboard.courseCard.button,
      link: createPageUrl('Course'),
      locked: false
    },
    {
      title: t.dashboard.liveCard.title,
      subtitle: t.dashboard.liveCard.subtitle,
      icon: Activity,
      iconColor: '#00ff88',
      highlight: t.dashboard.liveCard.ready,
      button: t.dashboard.liveCard.button,
      link: createPageUrl('Dashboard'),
      locked: false
    },
    {
      title: t.dashboard.analyticsCard.title,
      subtitle: t.dashboard.analyticsCard.subtitle,
      icon: BarChart3,
      iconColor: '#00f5ff',
      highlight: `+2.4 bb/100 ${t.dashboard.analyticsCard.highlight}`,
      button: t.dashboard.analyticsCard.button,
      link: createPageUrl('Analytics'),
      locked: !isPro
    },
    {
      title: t.dashboard.progressCard.title,
      subtitle: t.dashboard.progressCard.subtitle,
      icon: Trophy,
      iconColor: '#ffaa00',
      highlight: `85% ${t.dashboard.progressCard.adherence} · 4 ${t.dashboard.progressCard.badges}`,
      button: t.dashboard.progressCard.button,
      link: createPageUrl('Progress'),
      locked: !isPro
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0a] scanlines flex items-center justify-center p-6">
      <div className="max-w-6xl w-full">
        {/* Logo & Welcome */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <SharkLogo size={140} showText={true} />
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-4xl font-normal text-white mt-6 mb-3"
            style={{ fontFamily: 'Space Grotesk, sans-serif' }}
          >
            {t.dashboard.welcome}{user?.full_name ? `, ${user.full_name.split(' ')[0]}` : ''}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-white/50 text-lg"
          >
            {t.dashboard.subtitle}
          </motion.p>
        </motion.div>

        {/* 4 Column Hub Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {hubCards.map((card, index) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1 }}
              whileHover={{ scale: 1.02, y: -4 }}
              className="relative"
            >
              <Link
                to={card.link}
                className={`block p-5 rounded-2xl backdrop-blur-xl bg-gradient-to-br from-white/5 to-white/[0.02] border transition-all ${
                  card.locked 
                    ? 'border-white/10 cursor-not-allowed opacity-60' 
                    : 'border-white/20 hover:border-[#00f5ff]/40 hover:shadow-2xl'
                }`}
                style={{
                  boxShadow: card.locked ? 'none' : `0 0 40px ${card.iconColor}20`
                }}
                onClick={(e) => card.locked && e.preventDefault()}
              >
                {/* Lock Badge */}
                {card.locked && (
                  <div className="absolute top-4 right-4 p-2 rounded-full bg-white/10 border border-white/20">
                    <Lock className="w-4 h-4 text-white/50" />
                  </div>
                )}

                {/* Icon */}
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ 
                    backgroundColor: `${card.iconColor}15`,
                    border: `1px solid ${card.iconColor}30`,
                    boxShadow: card.locked ? 'none' : `0 0 25px ${card.iconColor}40`
                  }}
                >
                  <card.icon 
                    className="w-6 h-6" 
                    style={{ 
                      color: card.iconColor,
                      filter: card.locked ? 'none' : `drop-shadow(0 0 8px ${card.iconColor})`
                    }} 
                  />
                </div>

                {/* Title */}
                <h3 
                  className="text-lg font-normal text-white mb-2"
                  style={{ fontFamily: 'Space Grotesk, sans-serif' }}
                >
                  {card.title}
                </h3>

                {/* Subtitle */}
                <p className="text-white/50 text-xs mb-3">
                  {card.subtitle}
                </p>

                {/* Highlight */}
                <div className="mb-4">
                  <p className="text-white/80 font-medium text-sm">
                    {card.highlight}
                  </p>
                </div>

                {/* Button */}
                <div 
                  className={`flex items-center justify-between px-4 py-2 rounded-lg transition-all text-sm ${
                    card.locked
                      ? 'bg-white/5'
                      : 'glass-button'
                  }`}
                >
                  <span className={`font-medium ${card.locked ? 'text-white/40' : 'text-white'}`}>
                    {card.locked ? t.dashboard.proOnly : card.button}
                  </span>
                  {!card.locked && (
                    <ArrowRight className="w-4 h-4 text-[#00f5ff]" />
                  )}
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* GTO Launcher - Always visible */}
      <GTOLauncher isPro={isPro} />
    </div>
  );
}