import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Settings as SettingsIcon, 
  User, 
  CreditCard, 
  Bell, 
  Folder,
  LogOut,
  CheckCircle2,
  Crown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import GTOLauncher from '@/components/gto/GTOLauncher';

export default function Settings() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('profile');
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: subscriptionData } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.Subscription.filter({ user_email: user.email });
      return results[0] || { tier: 'free', status: 'active' };
    },
    enabled: !!user?.email
  });

  const upgradeMutation = useMutation({
    mutationFn: async () => {
      // Create Stripe checkout session
      const response = await base44.functions.invoke('createCheckout', {
        priceId: 'price_1QYT6MPNRjrb3o88KA9pN1xz' // Your Stripe price ID
      });
      
      // Redirect to Stripe checkout
      if (response.data.url) {
        window.location.href = response.data.url;
      }
    },
    onError: (error) => {
      console.error('Checkout error:', error);
    }
  });

  const isPro = true; // Always show Pro features in preview

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'subscription', label: 'Subscription', icon: CreditCard },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'gto-pulse', label: 'GTO Pulse', icon: Folder }
  ];

  return (
    <div className="min-h-screen bg-[#121212] p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <SettingsIcon className="w-8 h-8 text-cyan-400" />
            <h1 className="text-3xl font-normal text-white">Settings</h1>
          </div>
          <p className="text-white/60">
            Manage your account and preferences
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Tabs */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <div className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    activeTab === tab.id
                      ? 'bg-cyan-500/20 text-cyan-400'
                      : 'text-white/60 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  {tab.label}
                </button>
              ))}

              <hr className="border-white/10 my-4" />

              <button
                onClick={() => base44.auth.logout()}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left text-red-400 hover:bg-red-500/10 transition-colors"
              >
                <LogOut className="w-5 h-5" />
                Log Out
              </button>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-3"
          >
            {activeTab === 'profile' && (
              <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
                <h2 className="text-xl font-normal text-white mb-6">Profile Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <Label className="text-white/70">Full Name</Label>
                    <Input 
                      value={user?.full_name || ''} 
                      className="mt-2 bg-white/5 border-white/10 text-white"
                      disabled
                    />
                  </div>
                  <div>
                    <Label className="text-white/70">Email</Label>
                    <Input 
                      value={user?.email || ''} 
                      className="mt-2 bg-white/5 border-white/10 text-white"
                      disabled
                    />
                  </div>
                  <div>
                    <Label className="text-white/70">Member Since</Label>
                    <Input 
                      value={user?.created_date ? new Date(user.created_date).toLocaleDateString() : ''} 
                      className="mt-2 bg-white/5 border-white/10 text-white"
                      disabled
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'subscription' && (
              <div className="space-y-6">
                {/* Current Plan */}
                <div className={`rounded-2xl border p-6 ${
                  isPro 
                    ? 'bg-gradient-to-br from-cyan-900/30 to-teal-900/30 border-cyan-500/30' 
                    : 'bg-gradient-to-br from-gray-900 to-gray-950 border-white/10'
                }`}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      {isPro && <Crown className="w-6 h-6 text-amber-400" />}
                      <div>
                        <h2 className="text-xl font-normal text-white">
                          {isPro ? 'Pro Plan' : 'Free Plan'}
                        </h2>
                        <p className="text-white/60">
                          {isPro ? '$59/month' : '$0/month'}
                        </p>
                      </div>
                    </div>
                    {isPro && (
                      <div className="flex items-center gap-2 text-teal-400">
                        <CheckCircle2 className="w-5 h-5" />
                        <span className="text-sm font-medium">Active</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3">
                    {isPro ? (
                      <>
                        <div className="flex items-center gap-2 text-white/70">
                          <CheckCircle2 className="w-4 h-4 text-teal-400" />
                          Full 15-module course access
                        </div>
                        <div className="flex items-center gap-2 text-white/70">
                          <CheckCircle2 className="w-4 h-4 text-teal-400" />
                          GTO Pulse with 12 tables
                        </div>
                        <div className="flex items-center gap-2 text-white/70">
                          <CheckCircle2 className="w-4 h-4 text-teal-400" />
                          Session analytics & reports
                        </div>
                        <div className="flex items-center gap-2 text-white/70">
                          <CheckCircle2 className="w-4 h-4 text-teal-400" />
                          Progress tracking & badges
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center gap-2 text-white/70">
                          <CheckCircle2 className="w-4 h-4 text-teal-400" />
                          First 3 modules free
                        </div>
                        <div className="flex items-center gap-2 text-white/70">
                          <CheckCircle2 className="w-4 h-4 text-teal-400" />
                          GTO Pulse with 4 tables
                        </div>
                        <div className="flex items-center gap-2 text-white/50">
                          <div className="w-4 h-4 rounded-full border border-white/30" />
                          Analytics locked
                        </div>
                        <div className="flex items-center gap-2 text-white/50">
                          <div className="w-4 h-4 rounded-full border border-white/30" />
                          Progress tracking locked
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* Upgrade CTA */}
                {!isPro && (
                  <div className="bg-gradient-to-br from-amber-900/20 to-orange-900/20 rounded-2xl border border-amber-500/20 p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <Crown className="w-6 h-6 text-amber-400" />
                      <h3 className="text-xl font-normal text-white">Upgrade to Pro</h3>
                    </div>
                    <p className="text-white/60 mb-6">
                      Get full access to all 15 modules, unlimited GTO Pulse tables, 
                      session analytics, and progress tracking.
                    </p>
                    <Button
                      onClick={() => upgradeMutation.mutate()}
                      disabled={upgradeMutation.isPending}
                      className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:opacity-90 h-12 text-lg font-semibold"
                    >
                      {upgradeMutation.isPending ? 'Processing...' : 'Upgrade Now — $59/month'}
                    </Button>
                    <p className="text-center text-white/40 text-sm mt-3">
                      Cancel anytime. No commitment.
                    </p>
                  </div>
                )}

                {isPro && (
                  <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
                    <h3 className="text-lg font-normal text-white mb-4">Billing</h3>
                    <p className="text-white/60 mb-4">
                      Your next billing date is {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                    </p>
                    <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                      Manage Subscription
                    </Button>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
                <h2 className="text-xl font-normal text-white mb-6">Notification Settings</h2>
                
                <div className="space-y-6">
                  {[
                    { label: 'Course updates', description: 'New modules and content' },
                    { label: 'Session reminders', description: 'Daily practice notifications' },
                    { label: 'Progress milestones', description: 'Badge and achievement alerts' },
                    { label: 'Tips & insights', description: 'Weekly GTO strategy tips' }
                  ].map((item) => (
                    <div key={item.label} className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium">{item.label}</p>
                        <p className="text-sm text-white/50">{item.description}</p>
                      </div>
                      <Switch />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'gto-pulse' && (
              <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
                <h2 className="text-xl font-normal text-white mb-6">GTO Pulse Settings</h2>
                
                <div className="space-y-6">
                  <div>
                    <Label className="text-white/70">Hand History Folder</Label>
                    <p className="text-sm text-white/50 mb-3">
                      Select your poker client's hand history folder for real-time tracking
                    </p>
                    <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                      <Folder className="w-4 h-4 mr-2" />
                      Select Folder
                    </Button>
                  </div>

                  <hr className="border-white/10" />

                  <div>
                    <Label className="text-white/70">Supported Clients</Label>
                    <div className="grid grid-cols-2 gap-3 mt-3">
                      {['PokerStars', 'GGPoker', 'Winamax', '888 Poker'].map((client) => (
                        <div 
                          key={client}
                          className="p-3 rounded-lg bg-white/5 border border-white/10 text-white/70 text-sm"
                        >
                          {client}
                        </div>
                      ))}
                    </div>
                  </div>

                  <hr className="border-white/10" />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">Auto-detect hands</p>
                      <p className="text-sm text-white/50">Automatically detect new hands dealt</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">Sound alerts</p>
                      <p className="text-sm text-white/50">Play sound for premium hands</p>
                    </div>
                    <Switch />
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>

      <GTOLauncher isPro={isPro} />
    </div>
  );
}