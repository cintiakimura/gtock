import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  Trophy, 
  TrendingUp, 
  Target, 
  Lock,
  Calendar,
  Star
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import Badges from '@/components/analytics/Badges';
import GTOLauncher from '@/components/gto/GTOLauncher';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function Progress() {
  const [user, setUser] = useState(null);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: subscriptionData } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.Subscription.filter({ user_email: user.email });
      return results[0] || { tier: 'free' };
    },
    enabled: !!user?.email
  });

  const isPro = true; // Always show Pro features in preview

  // Demo data for progress tracking
  const progressData = timeRange === '7d' ? [
    { date: 'Mon', adherence: 72, improvement: 0 },
    { date: 'Tue', adherence: 68, improvement: -0.4 },
    { date: 'Wed', adherence: 75, improvement: 0.7 },
    { date: 'Thu', adherence: 71, improvement: -0.2 },
    { date: 'Fri', adherence: 78, improvement: 1.0 },
    { date: 'Sat', adherence: 82, improvement: 1.5 },
    { date: 'Sun', adherence: 85, improvement: 2.4 },
  ] : [
    { date: 'Week 1', adherence: 65, improvement: 0 },
    { date: 'Week 2', adherence: 70, improvement: 0.8 },
    { date: 'Week 3', adherence: 74, improvement: 1.4 },
    { date: 'Week 4', adherence: 80, improvement: 2.4 },
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-900 border border-white/10 rounded-lg p-3 shadow-xl">
          <p className="text-white/60 text-xs mb-1">{label}</p>
          <p className="text-white font-semibold">
            {payload[0]?.value}% Adherence
          </p>
          {payload[1] && (
            <p className={`text-sm ${payload[1].value >= 0 ? 'text-teal-400' : 'text-red-400'}`}>
              {payload[1].value >= 0 ? '+' : ''}{payload[1].value} bb/100
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-[#121212] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8"
        >
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Trophy className="w-8 h-8 text-amber-400" />
              <h1 className="text-3xl font-normal text-white">Progress</h1>
            </div>
            <p className="text-white/60">
              Track your GTO improvement over time
            </p>
          </div>

          <div className="flex bg-white/5 rounded-lg p-1">
            {['7d', '30d'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  timeRange === range
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {range === '7d' ? '7 Days' : '30 Days'}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
        >
          {[
            { label: 'Current Streak', value: '5 days', icon: Calendar, color: 'text-amber-400' },
            { label: 'GTO Adherence', value: '85%', icon: Target, color: 'text-cyan-400' },
            { label: 'Est. bb/100 Gain', value: '+2.4', icon: TrendingUp, color: 'text-teal-400' },
            { label: 'Badges Earned', value: '2/6', icon: Star, color: 'text-purple-400' }
          ].map((stat) => (
            <div 
              key={stat.label}
              className="p-5 rounded-2xl bg-gradient-to-br from-gray-900 to-gray-950 border border-white/10"
            >
              <stat.icon className={`w-5 h-5 ${stat.color} mb-3`} />
              <p className="text-white/50 text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
            </div>
          ))}
        </motion.div>

        {/* Progress Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6 mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-white">Improvement Over Time</h3>
              <p className="text-sm text-white/50">bb/100 improvement vs starting point</p>
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={progressData}>
                <defs>
                  <linearGradient id="improvementGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#14b8a6" stopOpacity={0.3}/>
                    <stop offset="100%" stopColor="#14b8a6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="date" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 12 }}
                />
                <YAxis 
                  yAxisId="left"
                  domain={[50, 100]}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 12 }}
                />
                <YAxis 
                  yAxisId="right"
                  orientation="right"
                  domain={[-2, 5]}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 12 }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  yAxisId="left"
                  type="monotone"
                  dataKey="adherence"
                  stroke="#00e5e5"
                  strokeWidth={2}
                  fill="url(#improvementGradient)"
                />
                <Line
                  yAxisId="right"
                  type="monotone"
                  dataKey="improvement"
                  stroke="#14b8a6"
                  strokeWidth={2}
                  dot={{ fill: '#14b8a6', r: 4 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-center gap-8 mt-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-cyan-400" />
              <span className="text-white/60">GTO Adherence %</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-teal-500" />
              <span className="text-white/60">bb/100 Improvement</span>
            </div>
          </div>
        </motion.div>

        {/* Badges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Badges earnedBadges={[]} progress={{}} />
        </motion.div>
      </div>

      <GTOLauncher isPro={isPro} />
    </div>
  );
}