import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { BookOpen, Search, Filter, CheckCircle2, Grid3x3, List } from 'lucide-react';
import { Input } from '@/components/ui/input';
import ModuleCard from '@/components/course/ModuleCard';
import { MODULES } from '@/components/course/ModuleContent';
import GTOLauncher from '@/components/gto/GTOLauncher';
import { getCurrentLanguage } from '@/components/utils/translations';

export default function Course() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [viewMode, setViewMode] = useState('grid');
  const [language, setLanguage] = useState(getCurrentLanguage());

  // Re-import when language changes
  useEffect(() => {
    const handleStorageChange = () => {
      setLanguage(getCurrentLanguage());
      window.location.reload();
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: progress } = useQuery({
    queryKey: ['courseProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.CourseProgress.filter({ user_email: user.email });
      return results[0] || { completed_modules: [], quiz_scores: {}, current_module: 1 };
    },
    enabled: !!user?.email
  });

  const { data: subscriptionData } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const results = await base44.entities.Subscription.filter({ user_email: user.email });
      return results[0] || { tier: 'free' };
    },
    enabled: !!user?.email
  });

  const isPro = true; // Always show Pro features in preview
  const completedModules = progress?.completed_modules || [];

  const filteredModules = MODULES.filter(module => {
    const matchesSearch = module.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         module.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filter === 'completed') return matchesSearch && completedModules.includes(module.id);
    if (filter === 'in-progress') return matchesSearch && !completedModules.includes(module.id);
    if (filter === 'free') return matchesSearch && module.free;
    return matchesSearch;
  });

  const completionPercent = Math.round((completedModules.length / MODULES.length) * 100);

  return (
    <div className="min-h-screen bg-[#0a0a0a] p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <BookOpen className="w-8 h-8 text-[#00f5ff]" />
            <h1 className="text-4xl font-normal text-white" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>Modules de Cours</h1>
          </div>
          <p className="text-white/60">
            15 modules pour maîtriser la stratégie GTO au poker
          </p>
        </motion.div>

        {/* Progress Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-6 rounded-2xl bg-gradient-to-br from-cyan-900/20 to-teal-900/20 border border-cyan-500/20 mb-8"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-normal text-white mb-1">Votre Progression</h2>
              <p className="text-white/60">
                {completedModules.length} sur {MODULES.length} modules terminés
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-48 h-3 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${completionPercent}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-cyan-500 to-teal-500"
                />
              </div>
              <span className="text-2xl font-bold text-white">{completionPercent}%</span>
            </div>
          </div>
        </motion.div>

        {/* Filters & Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col md:flex-row gap-4 mb-8"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <Input
              placeholder="Rechercher des modules..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/40"
            />
          </div>
          <div className="flex gap-2">
            <div className="flex gap-1 bg-white/5 rounded-lg p-1 mr-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'grid' ? 'bg-cyan-500/20 text-cyan-400' : 'text-white/60 hover:text-white'
                }`}
                title="Grid View"
              >
                <Grid3x3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'list' ? 'bg-cyan-500/20 text-cyan-400' : 'text-white/60 hover:text-white'
                }`}
                title="List View"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
            {[
              { key: 'all', label: 'Tous' },
              { key: 'completed', label: 'Terminés' },
              { key: 'in-progress', label: 'En cours' },
              { key: 'free', label: 'Gratuit' }
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filter === f.key
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Module Grid/List */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className={viewMode === 'grid' ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}
        >
          {filteredModules.map((module, index) => {
            const isCompleted = completedModules.includes(module.id);
            const isLocked = !module.free && !isPro;
            const isCurrent = module.id === (progress?.current_module || 1);
            
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * index }}
              >
                <ModuleCard
                  module={module}
                  isCompleted={isCompleted}
                  isLocked={isLocked}
                  progress={isCompleted ? 100 : isCurrent ? 50 : 0}
                  viewMode={viewMode}
                />
              </motion.div>
            );
          })}
        </motion.div>

        {filteredModules.length === 0 && (
          <div className="text-center py-16">
            <p className="text-white/50">Aucun module trouvé correspondant à votre recherche.</p>
          </div>
        )}
      </div>

      <GTOLauncher isPro={isPro} />
    </div>
  );
}