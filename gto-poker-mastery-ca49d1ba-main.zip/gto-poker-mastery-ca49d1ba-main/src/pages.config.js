import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import Course from './pages/Course';
import Module from './pages/Module';
import Analytics from './pages/Analytics';
import Progress from './pages/Progress';
import Settings from './pages/Settings';
import ManageContent from './pages/ManageContent';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Landing": Landing,
    "Dashboard": Dashboard,
    "Course": Course,
    "Module": Module,
    "Analytics": Analytics,
    "Progress": Progress,
    "Settings": Settings,
    "ManageContent": ManageContent,
}

export const pagesConfig = {
    mainPage: "Landing",
    Pages: PAGES,
    Layout: __Layout,
};