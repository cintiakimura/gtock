import React, { useState, useEffect } from 'react';
import { Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function LanguageSelector() {
  const [isOpen, setIsOpen] = useState(false);
  const [language, setLanguage] = useState('fr');

  useEffect(() => {
    const savedLang = localStorage.getItem('language') || 'fr';
    setLanguage(savedLang);
  }, []);

  const changeLanguage = (lang) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
    setIsOpen(false);
    window.location.reload(); // Reload to apply translations
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 rounded-lg hover:bg-white/10 transition-colors flex items-center gap-2 text-white/60 hover:text-white"
      >
        <Globe className="w-5 h-5" />
        <span className="text-sm font-medium">{language.toUpperCase()}</span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute right-0 top-12 z-50 w-32 bg-gray-900 border border-white/10 rounded-lg shadow-xl overflow-hidden"
            >
              <button
                onClick={() => changeLanguage('fr')}
                className={`w-full px-4 py-2 text-left hover:bg-white/5 transition-colors ${
                  language === 'fr' ? 'bg-cyan-500/20 text-cyan-400' : 'text-white/70'
                }`}
              >
                Français
              </button>
              <button
                onClick={() => changeLanguage('en')}
                className={`w-full px-4 py-2 text-left hover:bg-white/5 transition-colors ${
                  language === 'en' ? 'bg-cyan-500/20 text-cyan-400' : 'text-white/70'
                }`}
              >
                English
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}