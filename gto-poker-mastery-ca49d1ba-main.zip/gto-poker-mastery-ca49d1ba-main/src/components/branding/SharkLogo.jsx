import React from 'react';

export default function SharkLogo({ size = 120, showText = true, className = '' }) {
  const iconSize = size * 0.7;
  
  return (
    <div className={`flex flex-col items-center ${className}`}>
      {/* Shark Logo */}
      <div 
        className="relative flex items-center justify-center"
        style={{ 
          width: size, 
          height: size
        }}
      >
        <img 
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/694771cee5c3bdcbca49d1ba/3e8251a99_apexmainlogoright.png"
          alt="Full House GTO Logo"
          className="w-full h-full object-contain"
        />
      </div>
      
      {/* Text */}
      {showText && (
        <h1 
          className="mt-4 text-2xl font-normal text-white"
          style={{ fontFamily: 'Space Grotesk, sans-serif' }}
        >
          Full House GTO
        </h1>
      )}
    </div>
  );
}