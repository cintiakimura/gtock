import React from 'react';

export default function ApexLogo({ size = 40, className = '' }) {
  return (
    <div 
      className={`relative rounded-full bg-[#121212] flex items-center justify-center ${className}`}
      style={{ 
        width: size, 
        height: size,
        boxShadow: '0 0 20px rgba(0, 179, 179, 0.3)'
      }}
    >
      {/* Teal Triangle (Apex Symbol) */}
      <svg 
        width={size * 0.6} 
        height={size * 0.6} 
        viewBox="0 0 24 24" 
        fill="none"
      >
        <path
          d="M12 3 L21 20 L3 20 Z"
          fill="#00b3b3"
          stroke="#00e5e5"
          strokeWidth="1"
          style={{
            filter: 'drop-shadow(0 0 8px rgba(0, 229, 229, 0.6))'
          }}
        />
        {/* AH Letters */}
        <text
          x="12"
          y="16"
          textAnchor="middle"
          fill="white"
          fontSize="8"
          fontWeight="bold"
          fontFamily="sans-serif"
        >
          AH
        </text>
      </svg>
    </div>
  );
}

export function ApexIcon({ size = 24 }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none"
    >
      <path
        d="M12 3 L21 20 L3 20 Z"
        fill="#00b3b3"
        stroke="#00e5e5"
        strokeWidth="1"
      />
      <text
        x="12"
        y="16"
        textAnchor="middle"
        fill="white"
        fontSize="7"
        fontWeight="bold"
        fontFamily="sans-serif"
      >
        AH
      </text>
    </svg>
  );
}