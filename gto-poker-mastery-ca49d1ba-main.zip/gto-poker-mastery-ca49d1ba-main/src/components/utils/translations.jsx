export const translations = {
  fr: {
    nav: {
      dashboard: 'Tableau de bord',
      course: 'Cours',
      analytics: 'Analytiques',
      progress: 'Progression',
      settings: 'Paramètres'
    },
    dashboard: {
      welcome: 'Bienvenue',
      subtitle: 'Votre plateforme complète de maîtrise du poker',
      courseCard: {
        title: 'Cours & Formation',
        subtitle: '15 modules + vidéos + quiz',
        completed: 'terminés',
        button: 'Continuer'
      },
      liveCard: {
        title: 'Outil de Décision Live',
        subtitle: 'Cartes flottantes + conseils temps réel',
        ready: 'Prêt',
        button: 'Lancer'
      },
      analyticsCard: {
        title: 'Analytiques de Performance',
        subtitle: 'Fuites, EV sauvé, exploits',
        highlight: 'cette semaine',
        button: 'Voir Rapport'
      },
      progressCard: {
        title: 'Votre Progression',
        subtitle: 'Adhérence GTO + badges',
        adherence: 'adhérence',
        badges: 'badges',
        button: 'Suivre'
      },
      proOnly: 'Pro Seulement'
    }
  },
  en: {
    nav: {
      dashboard: 'Dashboard',
      course: 'Course',
      analytics: 'Analytics',
      progress: 'Progress',
      settings: 'Settings'
    },
    dashboard: {
      welcome: 'Welcome back',
      subtitle: 'Your complete poker mastery platform',
      courseCard: {
        title: 'Course & Training',
        subtitle: '15 modules + videos + quizzes',
        completed: 'completed',
        button: 'Continue Learning'
      },
      liveCard: {
        title: 'Live Decision Tool',
        subtitle: 'Floating cards + real-time advice',
        ready: 'Ready',
        button: 'Launch Tool'
      },
      analyticsCard: {
        title: 'Performance Analytics',
        subtitle: 'Leaks, EV saved, exploits',
        highlight: 'this week',
        button: 'View Report'
      },
      progressCard: {
        title: 'Your Progress',
        subtitle: 'GTO adherence + badges',
        adherence: 'adherence',
        badges: 'badges',
        button: 'Track Mastery'
      },
      proOnly: 'Pro Only'
    }
  }
};

export const getTranslation = (lang = 'fr') => {
  return translations[lang] || translations.fr;
};

export const getCurrentLanguage = () => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('language') || 'fr';
  }
  return 'fr';
};