import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X, GripVertical } from 'lucide-react';
import { getGlowClass, getBackgroundColor } from './GTOLogic';

export default function GTOCard({ 
  id, 
  position = "BTN", 
  equity = 0, 
  action = "FOLD", 
  insight = "", 
  strength = "weak",
  onClose,
  initialX = 100,
  initialY = 100
}) {
  const [pos, setPos] = useState({ x: initialX, y: initialY });
  const [dragging, setDragging] = useState(false);
  const cardRef = useRef(null);
  const dragOffset = useRef({ x: 0, y: 0 });

  const handleMouseDown = (e) => {
    if (e.target.closest('.close-btn')) return;
    setDragging(true);
    const rect = cardRef.current.getBoundingClientRect();
    dragOffset.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const handleMouseMove = (e) => {
    if (!dragging) return;
    setPos({
      x: e.clientX - dragOffset.current.x,
      y: e.clientY - dragOffset.current.y
    });
  };

  const handleMouseUp = () => {
    setDragging(false);
  };

  const handleTouchStart = (e) => {
    if (e.target.closest('.close-btn')) return;
    setDragging(true);
    const touch = e.touches[0];
    const rect = cardRef.current.getBoundingClientRect();
    dragOffset.current = {
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top
    };
  };

  const handleTouchMove = (e) => {
    if (!dragging) return;
    const touch = e.touches[0];
    setPos({
      x: touch.clientX - dragOffset.current.x,
      y: touch.clientY - dragOffset.current.y
    });
  };

  useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleTouchMove);
      window.addEventListener('touchend', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [dragging]);

  const actionColors = {
    FOLD: "text-red-400",
    OPEN: "text-cyan-400",
    RAISE: "text-green-400",
    CALL: "text-yellow-400"
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className={`
        fixed z-[9998] w-40 h-[100px] rounded-xl
        bg-[#121212]
        border backdrop-blur-xl
        draggable-card ${getGlowClass(strength)}
        ${dragging ? 'cursor-grabbing' : 'cursor-grab'}
        ${strength === 'premium' ? 'border-[#00ff88]' : strength === 'strong' ? 'border-[#ffaa00]' : 'border-[#666666]'}
      `}
      style={{ 
        left: pos.x, 
        top: pos.y,
        boxShadow: strength === 'premium' 
          ? '0 0 25px rgba(0, 255, 136, 0.4)' 
          : strength === 'strong' 
            ? '0 0 25px rgba(255, 170, 0, 0.4)' 
            : '0 0 15px rgba(102, 102, 102, 0.3)'
      }}
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
    >
      <div className="relative h-full p-2.5 flex flex-col justify-between">
        {/* Header */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-white">
            Table {id} — {position}
          </span>
          <button 
            className="close-btn p-0.5 hover:bg-white/10 rounded transition-colors"
            onClick={() => onClose(id)}
          >
            <X className="w-3 h-3 text-white/50 hover:text-white" />
          </button>
        </div>

        {/* Equity - Large */}
        <div className="text-center">
          <span className="text-4xl font-bold text-white tracking-tight leading-none">
            {equity}%
          </span>
        </div>

        {/* Action & Insight */}
        <div className="flex flex-col items-center">
          <span className={`text-lg font-bold ${actionColors[action] || 'text-white'} leading-none mb-0.5`}>
            {action}
          </span>
          <span className="text-[11px] text-gray-400 truncate max-w-full">
            {insight}
          </span>
        </div>
      </div>
    </motion.div>
  );
}