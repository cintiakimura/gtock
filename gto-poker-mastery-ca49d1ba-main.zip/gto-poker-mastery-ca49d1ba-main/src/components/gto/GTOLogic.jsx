// Hardcoded GTO Logic - No AI
export const PREFLOP_RANGES = {
  UTG: {
    open: ["77+", "AJo+", "KQo", "A9s+", "KJs+", "QJs"],
    "3bet": ["QQ+", "AK"]
  },
  HJ: {
    open: ["66+", "ATo+", "KQo", "A8s+", "KTs+", "QTs+", "JTs"],
    "3bet": ["JJ+", "AK", "AQs"]
  },
  CO: {
    open: ["55+", "A9o+", "KJo+", "QJo+", "A7s+", "K9s+", "QTs+", "JTs"],
    "3bet": ["TT+", "AK", "AJs+", "KQs"]
  },
  BTN: {
    open: ["22+", "A2o+", "K8o+", "Q9o+", "J9o+", "A2s+", "K7s+", "Q8s+", "J8s+", "T8s+", "98s+", "87s+", "76s+", "65s+", "54s+"],
    "3bet": ["88+", "AJs+", "AQo+", "KJs+"]
  },
  SB: {
    open: ["22+", "A2o+", "K6o+", "Q9o+", "J9o+", "A2s+", "K6s+", "Q8s+", "J8s+", "T8s+", "98s+", "87s+", "76s+", "65s+", "54s+"],
    "3bet": ["77+", "AJo+", "KQs", "A5s-A2s"]
  },
  BB: {
    call: ["88+", "AJo+", "KTs+", "QTs+", "JTs", "98s+", "pocket pairs", "suited connectors"],
    "3bet": ["99+", "AK", "AQs+", "KQs", "A5s-A3s"]
  }
};

export const EQUITY_MAP = {
  "AA": 85, "KK": 82, "QQ": 78, "JJ": 71, "TT": 69,
  "99": 66, "88": 64, "77": 62, "66": 60, "55": 58,
  "44": 56, "43": 54, "33": 52, "22": 50,
  "AKs": 68, "AKo": 65, "AQs": 66, "AQo": 63,
  "AJs": 64, "AJo": 61, "ATs": 62, "ATo": 59,
  "KQs": 63, "KQo": 60, "KJs": 61, "KJo": 58,
  "QJs": 59, "QJo": 56, "JTs": 57, "JTo": 54,
  "T9s": 54, "98s": 52, "87s": 50, "76s": 48, "65s": 46,
  "default": 40
};

export const PREMIUM_HANDS = ["AA", "KK", "QQ", "AKs", "AQs"];
export const STRONG_HANDS = ["AJs", "KQs", "99", "TT", "JJ", "AKo", "AJo"];

export const INSIGHTS = [
  "Raise — premium hand",
  "Raise — blocker advantage", 
  "Call — pot odds favorable",
  "Fold — out of range",
  "Exploit — villain wide",
  "Raise — villain folds often",
  "Call — implied odds",
  "Fold — dominated range"
];

export function parseHand(hand) {
  // Parse hand like "Ah Kd" -> { card1: "A", card2: "K", suited: false, pair: false }
  if (!hand || hand.length < 4) return null;
  
  const parts = hand.trim().split(/\s+/);
  if (parts.length !== 2) return null;
  
  const card1 = parts[0].charAt(0).toUpperCase();
  const suit1 = parts[0].charAt(1).toLowerCase();
  const card2 = parts[1].charAt(0).toUpperCase();
  const suit2 = parts[1].charAt(1).toLowerCase();
  
  const suited = suit1 === suit2;
  const pair = card1 === card2;
  
  return { card1, card2, suit1, suit2, suited, pair };
}

export function getHandNotation(parsed) {
  if (!parsed) return "??";
  const { card1, card2, suited, pair } = parsed;
  
  if (pair) return card1 + card1;
  
  // Order by rank
  const ranks = "AKQJT98765432";
  const idx1 = ranks.indexOf(card1);
  const idx2 = ranks.indexOf(card2);
  
  const high = idx1 < idx2 ? card1 : card2;
  const low = idx1 < idx2 ? card2 : card1;
  
  return high + low + (suited ? "s" : "o");
}

export function getEquity(handNotation) {
  return EQUITY_MAP[handNotation] || EQUITY_MAP.default;
}

export function getStrength(handNotation) {
  if (PREMIUM_HANDS.some(h => handNotation.startsWith(h.replace('s','').replace('o','')) || handNotation === h)) {
    return "premium";
  }
  if (STRONG_HANDS.some(h => handNotation.startsWith(h.replace('s','').replace('o','')) || handNotation === h)) {
    return "strong";
  }
  return "weak";
}

export function getAdvice(handNotation, position) {
  const strength = getStrength(handNotation);
  const positionRanges = PREFLOP_RANGES[position] || PREFLOP_RANGES.BTN;
  
  // Check if hand is in open range
  const isInOpenRange = checkHandInRange(handNotation, positionRanges.open || []);
  const isIn3BetRange = checkHandInRange(handNotation, positionRanges["3bet"] || []);
  
  if (isIn3BetRange) {
    return { action: "RAISE", insight: INSIGHTS[0] };
  }
  if (isInOpenRange) {
    return { action: "OPEN", insight: INSIGHTS[4] };
  }
  if (strength === "premium") {
    return { action: "RAISE", insight: INSIGHTS[0] };
  }
  if (strength === "strong") {
    return { action: "CALL", insight: INSIGHTS[6] };
  }
  return { action: "FOLD", insight: INSIGHTS[3] };
}

function checkHandInRange(handNotation, range) {
  for (const r of range) {
    // Check pair ranges like "77+"
    if (r.endsWith("+") && !r.includes("-")) {
      const minPair = r.replace("+", "");
      if (handNotation.length === 2 && handNotation[0] === handNotation[1]) {
        const ranks = "AKQJT98765432";
        const minIdx = ranks.indexOf(minPair[0]);
        const handIdx = ranks.indexOf(handNotation[0]);
        if (handIdx <= minIdx) return true;
      }
    }
    // Check specific hands
    if (handNotation === r) return true;
    if (handNotation.replace(/[so]$/, '') === r.replace(/[so]$/, '')) return true;
  }
  return false;
}

export function getGlowClass(strength) {
  switch(strength) {
    case "premium": return "glow-premium";
    case "strong": return "glow-strong";
    default: return "glow-weak";
  }
}

export function getBackgroundColor(strength) {
  switch(strength) {
    case "premium": return "from-green-900/40 to-green-950/60";
    case "strong": return "from-orange-900/40 to-orange-950/60";
    default: return "from-gray-800/40 to-gray-900/60";
  }
}

export const POSITIONS = ["UTG", "HJ", "CO", "BTN", "SB", "BB"];