import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Activity, Settings, Folder } from 'lucide-react';
import GTOCard from './GTOCard';
import { 
  parseHand, 
  getHandNotation, 
  getEquity, 
  getStrength, 
  getAdvice,
  POSITIONS 
} from './GTOLogic';

export default function GTOLauncher({ isPro = false }) {
  const [cards, setCards] = useState([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [pos, setPos] = useState({ x: 20, y: window.innerHeight - 160 });
  const [dragging, setDragging] = useState(false);
  const [showFolderSetup, setShowFolderSetup] = useState(false);
  const [handHistoryPath, setHandHistoryPath] = useState(null);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const launcherRef = useRef(null);
  const dragOffset = useRef({ x: 0, y: 0 });
  const nextTableId = useRef(1);

  const maxCards = isPro ? 12 : 4;

  const addCard = () => {
    if (cards.length >= maxCards) return;
    
    // Simulate a random hand for demo (in real app, this comes from hand history)
    const demoHands = [
      { hand: "Ah Kd", position: "BTN" },
      { hand: "Qc Qh", position: "CO" },
      { hand: "Ts 9s", position: "HJ" },
      { hand: "Ac 5c", position: "SB" },
      { hand: "7h 7d", position: "UTG" },
      { hand: "Kc Js", position: "BB" }
    ];
    
    const demo = demoHands[cards.length % demoHands.length];
    const parsed = parseHand(demo.hand);
    const notation = getHandNotation(parsed);
    const equity = getEquity(notation);
    const strength = getStrength(notation);
    const { action, insight } = getAdvice(notation, demo.position);

    const newCard = {
      id: nextTableId.current++,
      position: demo.position,
      equity,
      action,
      insight,
      strength,
      initialX: 200 + (cards.length * 30),
      initialY: 100 + (cards.length * 20)
    };
    
    setCards([...cards, newCard]);
  };

  const removeCard = (id) => {
    setCards(cards.filter(c => c.id !== id));
  };

  const handleMouseDown = (e) => {
    if (e.target.closest('button')) return;
    setDragging(true);
    const rect = launcherRef.current.getBoundingClientRect();
    dragOffset.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const handleMouseMove = (e) => {
    if (!dragging) return;
    setPos({
      x: Math.max(0, Math.min(window.innerWidth - 200, e.clientX - dragOffset.current.x)),
      y: Math.max(0, Math.min(window.innerHeight - 120, e.clientY - dragOffset.current.y))
    });
  };

  const handleMouseUp = () => setDragging(false);

  useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [dragging]);

  return (
    <>
      {/* Floating Cards */}
      <AnimatePresence>
        {cards.map(card => (
          <GTOCard 
            key={card.id} 
            {...card} 
            onClose={removeCard}
          />
        ))}
      </AnimatePresence>

      {/* Fixed Circular Launcher - Bottom Right */}
      <motion.button
        onClick={addCard}
        disabled={cards.length >= maxCards}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ scale: cards.length >= maxCards ? 1 : 1.1 }}
        whileTap={{ scale: cards.length >= maxCards ? 1 : 0.95 }}
        className={`
          fixed bottom-6 right-6 z-[9999]
          w-[60px] h-[60px] rounded-full
          flex items-center justify-center
          transition-all duration-200
          ${cards.length >= maxCards
            ? 'bg-gray-800 cursor-not-allowed opacity-50'
            : 'bg-gradient-to-br from-[#00b3b3] to-[#00e5e5] hover:shadow-2xl cursor-pointer'
          }
        `}
        style={{
          boxShadow: cards.length >= maxCards ? 'none' : '0 0 30px rgba(0, 229, 229, 0.5), 0 0 60px rgba(0, 179, 179, 0.3)'
        }}
        title={cards.length >= maxCards ? `Max ${maxCards} tables` : 'Add Stats Card'}
      >
        <Plus className="w-8 h-8 text-white" />
        
        {/* Card Counter Badge */}
        {cards.length > 0 && (
          <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-white flex items-center justify-center">
            <span className="text-xs font-bold text-[#00b3b3]">{cards.length}</span>
          </div>
        )}
      </motion.button>

      {/* Settings Gear - Small button next to launcher */}
      <motion.button
        onClick={() => setShowFolderSetup(true)}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className={`fixed bottom-6 right-20 z-[9999] w-[40px] h-[40px] rounded-full border flex items-center justify-center transition-colors ${
          handHistoryPath
            ? 'bg-cyan-500/20 border-cyan-500/50 hover:bg-cyan-500/30'
            : 'bg-gray-900/95 border-white/20 hover:bg-white/10'
        }`}
        title={handHistoryPath ? `Connected: ${handHistoryPath}` : 'GTO Pulse Settings'}
      >
        <Settings className={`w-5 h-5 ${handHistoryPath ? 'text-cyan-400' : 'text-white/60'}`} />
      </motion.button>

      {/* Folder Setup Modal */}
      <AnimatePresence>
        {showFolderSetup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-[10000] flex items-center justify-center p-4"
            onClick={() => setShowFolderSetup(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gray-900 border border-white/10 rounded-2xl p-6 max-w-md w-full"
              onClick={e => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold text-white mb-4">Hand History Folder</h3>
              <p className="text-white/60 text-sm mb-4">
                Select your poker client's hand history folder to enable real-time hand detection.
              </p>
              
              <div className="space-y-3 mb-6">
                {[
                  { name: 'Winamax', path: '~/AppData/Local/Winamax/HandHistory/' },
                  { name: 'PokerStars', path: '~/AppData/Local/PokerStars/HandHistory/' },
                  { name: 'GG Poker', path: '~/Documents/GGPoker/HandHistory/' }
                ].map(room => (
                  <button
                    key={room.name}
                    onClick={() => setSelectedRoom(room)}
                    className={`w-full p-3 rounded-lg border transition-all text-left ${
                      selectedRoom?.name === room.name
                        ? 'bg-cyan-500/20 border-cyan-500/50'
                        : 'bg-white/5 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <p className="text-xs text-white/40 mb-1">{room.name}</p>
                    <p className="text-sm text-white/70 font-mono">{room.path}</p>
                  </button>
                ))}
              </div>

              <p className="text-xs text-white/40 mb-4 text-center">
                Note: File system access requires the desktop version.
                <br />Demo mode uses simulated hands.
              </p>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setHandHistoryPath(null);
                    setSelectedRoom(null);
                    setShowFolderSetup(false);
                  }}
                  className="flex-1 py-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-white text-sm font-medium transition-colors"
                >
                  Use Demo Mode
                </button>
                <button
                  onClick={() => {
                    if (selectedRoom) {
                      setHandHistoryPath(selectedRoom.path);
                    }
                    setShowFolderSetup(false);
                  }}
                  disabled={!selectedRoom}
                  className={`flex-1 py-2.5 rounded-lg text-white text-sm font-bold transition-colors ${
                    selectedRoom
                      ? 'bg-gradient-to-r from-cyan-500 to-teal-500 hover:opacity-90'
                      : 'bg-gray-700 opacity-50 cursor-not-allowed'
                  }`}
                >
                  Register Folder
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}