import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Target, Zap, Star, Award, Shield } from 'lucide-react';

const BADGES = [
  {
    id: 'preflop_crusher',
    name: 'Preflop Crusher',
    description: '90%+ GTO adherence preflop',
    icon: Zap,
    color: 'from-yellow-500 to-orange-500',
    requirement: 90
  },
  {
    id: 'river_master',
    name: 'River Master',
    description: 'Perfect river decisions for 50+ hands',
    icon: Target,
    color: 'from-cyan-500 to-blue-500',
    requirement: 50
  },
  {
    id: 'week_warrior',
    name: 'Week Warrior',
    description: 'Played 1000+ hands in a week',
    icon: Shield,
    color: 'from-green-500 to-teal-500',
    requirement: 1000
  },
  {
    id: 'bluff_artist',
    name: 'Bluff Artist',
    description: 'Optimal bluff frequency for 100+ spots',
    icon: Star,
    color: 'from-purple-500 to-pink-500',
    requirement: 100
  },
  {
    id: 'value_king',
    name: 'Value King',
    description: 'Perfect value betting for 200+ hands',
    icon: Trophy,
    color: 'from-amber-500 to-yellow-500',
    requirement: 200
  },
  {
    id: 'fold_warrior',
    name: 'Fold Warrior',
    description: 'Never spewed in 500+ hands',
    icon: Award,
    color: 'from-rose-500 to-red-500',
    requirement: 500
  }
];

export default function Badges({ earnedBadges = [], progress = {} }) {
  const demoBadges = ['preflop_crusher', 'week_warrior'];
  const demoProgress = {
    'river_master': 35,
    'bluff_artist': 78,
    'value_king': 120,
    'fold_warrior': 200
  };

  const earned = earnedBadges.length > 0 ? earnedBadges : demoBadges;
  const prog = Object.keys(progress).length > 0 ? progress : demoProgress;

  return (
    <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-amber-500/20">
          <Award className="w-5 h-5 text-amber-400" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white">Achievements</h3>
          <p className="text-sm text-white/50">{earned.length} of {BADGES.length} earned</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {BADGES.map((badge, index) => {
          const isEarned = earned.includes(badge.id);
          const currentProgress = prog[badge.id] || 0;
          const progressPercent = Math.min((currentProgress / badge.requirement) * 100, 100);
          const Icon = badge.icon;

          return (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className={`
                relative p-4 rounded-xl border transition-all
                ${isEarned 
                  ? 'bg-gradient-to-br from-white/10 to-transparent border-white/20' 
                  : 'bg-white/5 border-white/5 opacity-60'
                }
              `}
            >
              <div className={`
                w-12 h-12 rounded-xl mb-3 flex items-center justify-center
                ${isEarned 
                  ? `bg-gradient-to-br ${badge.color}` 
                  : 'bg-gray-800'
                }
              `}>
                <Icon className={`w-6 h-6 ${isEarned ? 'text-white' : 'text-gray-600'}`} />
              </div>
              
              <h4 className={`font-medium mb-1 ${isEarned ? 'text-white' : 'text-gray-500'}`}>
                {badge.name}
              </h4>
              <p className="text-xs text-white/40 mb-2">{badge.description}</p>

              {!isEarned && (
                <div className="mt-2">
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className={`h-full bg-gradient-to-r ${badge.color}`}
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-white/30 mt-1">
                    {currentProgress}/{badge.requirement}
                  </p>
                </div>
              )}

              {isEarned && (
                <div className="absolute top-2 right-2">
                  <div className="w-5 h-5 rounded-full bg-teal-500 flex items-center justify-center">
                    <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}