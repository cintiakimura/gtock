import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { TrendingUp, Target, Award } from 'lucide-react';

export default function ProgressChart({ data = [], timeRange = '7d' }) {
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-900 border border-white/10 rounded-lg p-3 shadow-xl">
          <p className="text-white/60 text-xs mb-1">{label}</p>
          <p className="text-white font-semibold">
            {payload[0].value}% GTO Adherence
          </p>
        </div>
      );
    }
    return null;
  };

  // Demo data
  const demoData = timeRange === '7d' ? [
    { date: 'Mon', adherence: 72, hands: 150 },
    { date: 'Tue', adherence: 68, hands: 200 },
    { date: 'Wed', adherence: 75, hands: 180 },
    { date: 'Thu', adherence: 71, hands: 220 },
    { date: 'Fri', adherence: 78, hands: 190 },
    { date: 'Sat', adherence: 82, hands: 300 },
    { date: 'Sun', adherence: 85, hands: 280 },
  ] : [
    { date: 'Week 1', adherence: 65, hands: 1200 },
    { date: 'Week 2', adherence: 70, hands: 1400 },
    { date: 'Week 3', adherence: 74, hands: 1100 },
    { date: 'Week 4', adherence: 80, hands: 1600 },
  ];

  const chartData = data.length > 0 ? data : demoData;
  const avgAdherence = Math.round(chartData.reduce((a, b) => a + b.adherence, 0) / chartData.length);
  const improvement = chartData.length > 1 
    ? chartData[chartData.length - 1].adherence - chartData[0].adherence 
    : 0;

  return (
    <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-white">GTO Adherence</h3>
          <p className="text-sm text-white/50">How often you followed GTO advice</p>
        </div>
        <div className="flex items-center gap-2">
          {improvement > 0 && (
            <div className="flex items-center gap-1 text-teal-400 text-sm">
              <TrendingUp className="w-4 h-4" />
              <span>+{improvement}%</span>
            </div>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="p-3 rounded-xl bg-white/5">
          <p className="text-xs text-white/40 mb-1">Average</p>
          <p className="text-2xl font-bold text-white">{avgAdherence}%</p>
        </div>
        <div className="p-3 rounded-xl bg-white/5">
          <p className="text-xs text-white/40 mb-1">Best Day</p>
          <p className="text-2xl font-bold text-teal-400">
            {Math.max(...chartData.map(d => d.adherence))}%
          </p>
        </div>
        <div className="p-3 rounded-xl bg-white/5">
          <p className="text-xs text-white/40 mb-1">Hands</p>
          <p className="text-2xl font-bold text-cyan-400">
            {chartData.reduce((a, b) => a + b.hands, 0).toLocaleString()}
          </p>
        </div>
      </div>

      {/* Chart */}
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="adherenceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00e5e5" stopOpacity={0.3}/>
                <stop offset="100%" stopColor="#00e5e5" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="date" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 12 }}
            />
            <YAxis 
              domain={[50, 100]}
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="adherence"
              stroke="#00e5e5"
              strokeWidth={2}
              fill="url(#adherenceGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}