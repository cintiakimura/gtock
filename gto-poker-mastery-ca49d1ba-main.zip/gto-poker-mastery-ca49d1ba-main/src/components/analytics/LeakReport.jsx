import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, TrendingDown, Lightbulb } from 'lucide-react';

export default function LeakReport({ leaks = [], insights = [] }) {
  const demoLeaks = [
    { leak: "Overfolded BB defense vs BTN opens", ev_loss: 4.2 },
    { leak: "Under-bluffed river spots with blockers", ev_loss: 2.8 },
    { leak: "Called too wide OOP in 3-bet pots", ev_loss: 2.1 },
  ];

  const demoInsights = [
    "3-bet more from BTN vs CO opens — villain folds 68%",
    "Increase probe bet frequency on wet turns after x/x flop",
    "Value bet thinner on paired boards — population undercalls",
  ];

  const displayLeaks = leaks.length > 0 ? leaks : demoLeaks;
  const displayInsights = insights.length > 0 ? insights : demoInsights;

  return (
    <div className="space-y-6">
      {/* Leaks Section */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-red-500/20">
            <AlertTriangle className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Top Leaks</h3>
            <p className="text-sm text-white/50">Areas costing you bb/100</p>
          </div>
        </div>

        <div className="space-y-3">
          {displayLeaks.map((leak, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between p-4 rounded-xl bg-red-500/5 border border-red-500/10"
            >
              <div className="flex items-center gap-3">
                <span className="text-lg font-bold text-red-400">#{index + 1}</span>
                <p className="text-white/80">{leak.leak}</p>
              </div>
              <div className="flex items-center gap-2 text-red-400">
                <TrendingDown className="w-4 h-4" />
                <span className="font-semibold">-{leak.ev_loss} bb/100</span>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-4 p-3 rounded-xl bg-white/5">
          <p className="text-sm text-white/50">
            Total estimated EV loss: <span className="text-red-400 font-semibold">
              -{displayLeaks.reduce((a, b) => a + b.ev_loss, 0).toFixed(1)} bb/100
            </span>
          </p>
        </div>
      </div>

      {/* Insights Section */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-cyan-500/20">
            <Lightbulb className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Personalized Insights</h3>
            <p className="text-sm text-white/50">Exploits based on your sessions</p>
          </div>
        </div>

        <div className="space-y-3">
          {displayInsights.map((insight, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-start gap-3 p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/10"
            >
              <div className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                <span className="text-xs font-bold text-cyan-400">{index + 1}</span>
              </div>
              <p className="text-white/80">{insight}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}