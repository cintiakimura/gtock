import { getCurrentLanguage } from '../utils/translations';

// Course module content data with translations
const MODULES_DATA = {
  fr: [
    {
      id: 1,
      title: "Introduction au GTO vs Jeu Exploitatoire",
      description: "Comprendre ce que signifie le GTO et quand utiliser des stratégies exploitatoires.",
      duration: "25 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: true
    },
    {
      id: 2,
      title: "Mathématiques et Concepts de Base du Poker",
      description: "Maîtriser les cotes du pot, l'équité, l'EV et la combinatoire.",
      duration: "35 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: true
    },
    {
      id: 3,
      title: "Fondamentaux Préflop",
      description: "Ranges basées sur la position, profondeurs de tapis et maîtrise des charts.",
      duration: "40 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: true
    },
    {
      id: 4,
      title: "Jeu au Flop dans les Pots Single Raised",
      description: "Textures de board, stratégies de c-bet et réponses du défenseur.",
      duration: "45 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 5,
      title: "Jeu à la Turn et River dans les SRP",
      description: "Barreling, probe bets, overbets à la river et polarisation.",
      duration: "50 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 6,
      title: "Pots 3-Bet & 4-Bet",
      description: "Construire et défendre les ranges de 3-bet.",
      duration: "45 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 7,
      title: "Pots Multiway",
      description: "Ajustements GTO lorsque plusieurs joueurs sont impliqués.",
      duration: "35 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 8,
      title: "Introduction aux Solvers",
      description: "Comment fonctionnent les solvers et comment interpréter leurs résultats.",
      duration: "40 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 9,
      title: "Solutions Solver Préflop",
      description: "Analyse approfondie des outputs solver préflop par position.",
      duration: "50 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 10,
      title: "Pratique Solver Postflop",
      description: "Analyse pratique de scénarios flop, turn et river.",
      duration: "55 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 11,
      title: "Exploiter les Déviations",
      description: "Identifier et punir les erreurs des adversaires.",
      duration: "45 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 12,
      title: "Ajustements GTO en Tournoi",
      description: "ICM, jeu de bulle et stratégies short-stack.",
      duration: "50 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 13,
      title: "Stratégies Avancées",
      description: "Stratégies mixtes, blocking bets et overbets.",
      duration: "55 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 14,
      title: "Mental Game & Routine d'Étude",
      description: "Gestion du tilt, concentration et apprentissage optimal.",
      duration: "30 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 15,
      title: "Capstone : Intégration Complète",
      description: "Tout assembler avec des revues de mains complètes.",
      duration: "60 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    }
  ],
  en: [
    {
      id: 1,
      title: "Introduction to GTO vs Exploitative Play",
      description: "Understand what GTO means and when to use exploitative strategies.",
      duration: "25 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: true
    },
    {
      id: 2,
      title: "Core Poker Math & Concepts",
      description: "Master pot odds, equity, EV, and combinatorics.",
      duration: "35 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: true
    },
    {
      id: 3,
      title: "Preflop Fundamentals",
      description: "Position-based ranges, stack depths, and chart mastery.",
      duration: "40 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: true
    },
    {
      id: 4,
      title: "Flop Play in Single Raised Pots",
      description: "Board textures, c-bet strategies, and defender responses.",
      duration: "45 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 5,
      title: "Turn & River Play in SRP",
      description: "Barreling, probe bets, river overbets, and polarization.",
      duration: "50 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 6,
      title: "3-Bet & 4-Bet Pots",
      description: "Constructing and defending 3-bet ranges.",
      duration: "45 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 7,
      title: "Multiway Pots",
      description: "GTO adjustments when multiple players are involved.",
      duration: "35 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 8,
      title: "Introduction to Solvers",
      description: "How solvers work and how to interpret their output.",
      duration: "40 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 9,
      title: "Preflop Solver Solutions",
      description: "Deep dive into preflop solver outputs by position.",
      duration: "50 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 10,
      title: "Postflop Solver Practice",
      description: "Hands-on analysis of flop, turn, and river scenarios.",
      duration: "55 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 11,
      title: "Exploiting Deviations",
      description: "Identifying and punishing opponent mistakes.",
      duration: "45 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 12,
      title: "Tournament GTO Adjustments",
      description: "ICM, bubble play, and short-stack strategies.",
      duration: "50 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 13,
      title: "Advanced Strategies",
      description: "Mixed strategies, blocking bets, and overbets.",
      duration: "55 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 14,
      title: "Mental Game & Study Routine",
      description: "Tilt management, focus, and optimal learning.",
      duration: "30 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    },
    {
      id: 15,
      title: "Capstone: Full Integration",
      description: "Putting it all together with comprehensive hand reviews.",
      duration: "60 min",
      videoUrl: null,
      video_fr: null,
      video_en: null,
      podcast_fr: null,
      podcast_en: null,
      slides_fr: null,
      slides_en: null,
      infographic_fr: null,
      infographic_en: null,
      free: false
    }
  ]
};

const MODULE_CONTENT_DATA = {
  fr: {
    1: `# Module 1 : Introduction au GTO vs Jeu Exploitatoire

## Objectifs d'Apprentissage
À la fin de ce module, vous serez capable de :
- Comprendre ce que signifie le jeu **Game Theory Optimal (GTO)** au poker
- Différencier les stratégies GTO et exploitatoires
- Saisir les concepts fondamentaux de minimax, Équilibre de Nash et jeu inexploitable
- Reconnaître quand utiliser le GTO comme base et quand s'en écarter

## Qu'est-ce que le GTO ?
**Game Theory Optimal (GTO)** est une stratégie théoriquement **inexploitable**—ce qui signifie que si vous jouez un GTO parfait, aucun adversaire ne peut obtenir un avantage à long terme contre vous, même s'ils connaissent votre stratégie exacte.

Le GTO provient de la **théorie des jeux**, initiée par John von Neumann et John Nash au milieu du 20ème siècle.

## Le Principe Minimax
Le fondement du GTO est le **théorème minimax** : Dans tout jeu à somme nulle à deux joueurs, il existe une stratégie où un joueur minimise sa perte maximale.

Au poker : Vous jouez de manière à minimiser ce qu'un adversaire parfait peut exploiter, tout en maximisant votre EV contre lui.

## Équilibre de Nash au Poker
Un **Équilibre de Nash** est un ensemble de stratégies où aucun joueur ne peut améliorer son EV en changeant unilatéralement sa stratégie.

Au No-Limit Hold'em full-ring, nous utilisons des **solvers** (comme PioSolver ou GTO+) pour approximer les stratégies d'Équilibre de Nash.

## Une Analogie Simple : Pierre-Papier-Ciseaux
La stratégie GTO (Nash) : Jouer chaque option **33,3%** du temps.

- Si vous jouez seulement Pierre, l'adversaire exploite en jouant toujours Papier
- Si vous jouez équilibré 33,3%, l'adversaire ne peut pas obtenir d'avantage

Le poker fonctionne de la même manière : Bluffer exactement assez pour que les mains fortes soient payées.

## GTO vs Jeu Exploitatoire

| Aspect | Stratégie GTO | Stratégie Exploitatoire |
|--------|---------------|------------------------|
| **Force** | Inexploitable ; base solide | EV maximum contre les faiblesses connues |
| **Faiblesse** | Laisse de l'argent sur la table vs mauvais joueurs | Peut être contrée si l'adversaire s'adapte |
| **Meilleur Contre** | Adversaires forts et adaptatifs | Adversaires prévisibles avec des leaks |

## Points Clés
- Le GTO est une question d'**équilibre** et d'**indifférence**
- Commencez avec le GTO pour construire un jeu solide sans leaks
- En jeu réel, utilisez le GTO par défaut et déviez quand vous identifiez des exploits rentables`,

    2: `# Module 2 : Mathématiques et Concepts de Base du Poker

## Objectifs d'Apprentissage
- Maîtriser les outils mathématiques fondamentaux qui sous-tendent toutes les décisions GTO
- Calculer avec précision les cotes du pot, l'équité et la fold equity requise
- Comprendre la Valeur Attendue (EV) et comment l'utiliser
- Construire et analyser des ranges avec la combinatoire

## Cotes du Pot
Les **cotes du pot** sont le ratio de la taille actuelle du pot par rapport au coût d'un call envisagé.

**Formule** : Équité Requise = Mise / (Pot + Mise + Mise)

**Exemple** : Le pot est de 100$, l'adversaire mise 50$.
- Pot total après call : 200$
- Équité requise : 50 / 200 = **25%**

## Équité et Fold Equity
L'**Équité** est votre part du pot basée sur la probabilité de gagner à l'abattage.

La **Fold Equity** est l'équité additionnelle gagnée lorsque les adversaires se couchent face à vos mises/bluffs.

## Valeur Attendue (EV)
**EV** = (Probabilité de Gagner × Montant Gagné) - (Probabilité de Perdre × Montant Perdu)

Utilisez l'EV pour comparer les lignes : Miser vs checker, caller vs relancer.

## Comptage de Combos
- Mains assorties (ex: AKs) : **4 combos**
- Mains dépareillées (ex: AKo) : **12 combos**
- Paires : **6 combos**

Quand des cartes sont au board, retirez ces combos (card removal).

## Blockers et Unblockers
**Blockers** : Cartes dans votre main qui réduisent les combos dans la range adverse.
**Unblockers** : Cartes que vous ne détenez pas qui maintiennent la range adverse large.

**Exemple** : Détenir A♠ sur un board avec tirage couleur bloque le nuts flush adverse → bon spot de bluff.`,

    3: `# Module 3 : Fondamentaux Préflop

## La Position est Reine
- **Early (UTG/MP)** : Ranges serrées (10-15%)
- **Late (CO/BTN)** : Plus larges (30-50%)
- **Blinds** : Voler large, défendre sélectivement

## Ranges Préflop par Position (100bb 6-Max)

| Position | Range RFI | 3-Bet |
|----------|-----------|-------|
| **UTG** | 14-16% | QQ+/AK |
| **HJ** | 18-20% | TT+/AQ+ |
| **CO** | 25-28% | 99+/AJ+ |
| **BTN** | 40-45% | 77+/ATo+ |
| **SB** | 55-65% vs BB | 66+/AJo+ |

## Effets de la Profondeur de Tapis
- **100bb** : Relances équilibrées, jeu postflop profond
- **Shallow (20-50bb)** : RFI plus large, plus de shoves
- **Deep (150bb+)** : Légèrement plus serré early, plus de suited connectors

## Points Clés
- **Position > Cartes** : Ouvrir plus large en position tardive
- Mémoriser RFI : UTG 15%, BTN 45%
- Profondeur de tapis : Shallow = shove plus, deep = suited connectors`
  },
  en: {
    1: `# Module 1: Introduction to GTO vs Exploitative Play

## Learning Objectives
By the end of this module, you will:
- Understand what **Game Theory Optimal (GTO)** play means in poker
- Differentiate between GTO and exploitative strategies
- Grasp the core ideas of minimax, Nash Equilibrium, and unexploitable play
- Recognize when to use GTO as a baseline and when to deviate

## What is GTO?
**Game Theory Optimal (GTO)** is a strategy that is theoretically **unexploitable**—meaning that if you play perfect GTO, no opponent can gain a long-term edge over you, even if they know your exact strategy.

GTO emerged from **game theory**, pioneered by John von Neumann and John Nash in the mid-20th century.

## The Minimax Principle
The foundation of GTO is the **minimax theorem**: In any two-player zero-sum game, there exists a strategy where one player minimizes their maximum loss.

In poker: You play in a way that minimizes the amount a perfect opponent can exploit you for, while maximizing your EV against them.

## Nash Equilibrium in Poker
A **Nash Equilibrium** is a set of strategies where no player can improve their EV by unilaterally changing their strategy.

In full-ring No-Limit Hold'em, we use **solvers** (like PioSolver or GTO+) to approximate Nash Equilibrium strategies.

## A Simple Analogy: Rock-Paper-Scissors
The GTO (Nash) strategy: Play each option **33.3%** of the time.

- If you play only Rock, opponent exploits by always playing Paper
- If you play balanced 33.3%, opponent cannot gain an edge

Poker works the same way: Bluff exactly enough that strong hands get paid off.

## GTO vs Exploitative Play

| Aspect | GTO Strategy | Exploitative Strategy |
|--------|--------------|----------------------|
| **Strength** | Unexploitable; solid baseline | Maximum EV against known weaknesses |
| **Weakness** | Leaves money on table vs bad players | Can be countered if opponent adapts |
| **Best Against** | Strong, adaptive opponents | Predictable, leaky opponents |

## Key Takeaways
- GTO is about **balance** and **indifference**
- Start with GTO to build a strong, leak-free game
- In real play, use GTO as your default and deviate when you identify profitable exploits`,

    2: `# Module 2: Core Poker Math & Concepts

## Learning Objectives
- Master the fundamental math tools that underpin all GTO decisions
- Calculate pot odds, equity, and required fold equity accurately
- Understand Expected Value (EV) and how to use it
- Construct and analyze ranges using combinatorics

## Pot Odds
**Pot odds** are the ratio of the current pot size to the cost of a contemplated call.

**Formula**: Required Equity = Bet / (Pot + Bet + Bet)

**Example**: Pot is $100, opponent bets $50.
- Total pot after call: $200
- Required equity: 50 / 200 = **25%**

## Equity and Fold Equity
**Equity** is your share of the pot based on probability of winning at showdown.

**Fold Equity** is additional equity gained from opponents folding to your bets/bluffs.

## Expected Value (EV)
**EV** = (Probability of Winning × Amount Won) - (Probability of Losing × Amount Lost)

Use EV to compare lines: Betting vs checking, calling vs raising.

## Combo Counting
- Suited hands (e.g., AKs): **4 combos**
- Offsuit hands (e.g., AKo): **12 combos**
- Pocket pairs: **6 combos**

When cards are on board, remove those combos (card removal).

## Blockers and Unblockers
**Blockers**: Cards in your hand that reduce combos in villain's range.
**Unblockers**: Cards you don't hold that keep villain's range wide.

**Example**: Holding A♠ on a flush draw board blocks villain's nut flush → good bluff spot.`,

    3: `# Module 3: Preflop Fundamentals

## Position is King
- **Early (UTG/MP)**: Tight ranges (10-15%)
- **Late (CO/BTN)**: Wider (30-50%)
- **Blinds**: Steal wide, defend selectively

## Preflop Ranges by Position (100bb 6-Max)

| Position | RFI Range | 3-Bet |
|----------|-----------|-------|
| **UTG** | 14-16% | QQ+/AK |
| **HJ** | 18-20% | TT+/AQ+ |
| **CO** | 25-28% | 99+/AJ+ |
| **BTN** | 40-45% | 77+/ATo+ |
| **SB** | 55-65% vs BB | 66+/AJo+ |

## Stack Depth Effects
- **100bb**: Balanced raises, deep postflop play
- **Shallow (20-50bb)**: Wider RFI, more shoves
- **Deep (150bb+)**: Slightly tighter early, more suited connectors

## Key Takeaways
- **Position > Cards**: Open wider late
- Memorize RFI: UTG 15%, BTN 45%
- Stack depth: Shallow = shove more, deep = spec connectors`
  }
};

const QUIZZES_DATA = {
  fr: {
    1: [
      {
        question: "Quel est l'objectif principal d'une stratégie poker GTO ?",
        options: [
          "Maximiser les gains à chaque main",
          "Être inexploitable par les adversaires",
          "Toujours bluffer à la bonne fréquence",
          "Jouer le plus agressivement possible"
        ],
        correctAnswer: 1,
        explanation: "Le GTO est une stratégie défensive axée sur l'inexploitabilité."
      },
      {
        question: "À Pierre-Papier-Ciseaux, qu'est-ce qui rend votre stratégie inexploitable ?",
        options: [
          "Toujours jouer Pierre",
          "Jouer selon votre ressenti",
          "Jouer chaque option 33,3% du temps",
          "Contrer votre adversaire"
        ],
        correctAnswer: 2,
        explanation: "Jouer chaque option avec une fréquence égale empêche l'exploitation."
      },
      {
        question: "Quand devriez-vous dévier du GTO vers un jeu exploitatoire ?",
        options: [
          "Jamais, le GTO est toujours optimal",
          "Quand vous identifiez des faiblesses rentables chez l'adversaire",
          "Seulement en tournoi",
          "Quand vous perdez"
        ],
        correctAnswer: 1,
        explanation: "Exploitez quand vous identifiez des leaks cohérents dans le jeu adverse."
      }
    ],
    2: [
      {
        question: "Le pot est de 100$, l'adversaire mise 100$. Quelle équité avez-vous besoin pour caller ?",
        options: ["25%", "33%", "50%", "66%"],
        correctAnswer: 1,
        explanation: "100 / (100 + 100 + 100) = 33%"
      },
      {
        question: "Combien de combos d'AK le vilain a-t-il préflop ?",
        options: ["4", "12", "16", "8"],
        correctAnswer: 2,
        explanation: "4 assortis + 12 dépareillés = 16 combos au total"
      },
      {
        question: "Vous avez A♦ sur un board avec couleur possible. C'est bon pour bluffer car :",
        options: [
          "Ça bloque les nuts",
          "Ça ne bloque pas les nuts",
          "Les As font peur",
          "Ça améliore votre équité"
        ],
        correctAnswer: 0,
        explanation: "Détenir l'A♦ bloque les combos de nuts flush du vilain."
      }
    ],
    3: [
      {
        question: "Quelle est votre range RFI approximative depuis BTN (100bb) ?",
        options: ["15%", "25%", "42%", "60%"],
        correctAnswer: 2,
        explanation: "BTN ouvre environ 40-45% des mains."
      },
      {
        question: "À 30bb effectifs, comment devriez-vous ajuster votre RFI ?",
        options: [
          "Plus serré, moins de mains",
          "Pareil qu'à 100bb",
          "Plus large, plus de shoves IP",
          "Seulement des mains premium"
        ],
        correctAnswer: 2,
        explanation: "Les tapis courts signifient des ranges d'ouverture plus larges et plus de pression all-in."
      }
    ]
  },
  en: {
    1: [
      {
        question: "What is the primary goal of a GTO poker strategy?",
        options: [
          "To maximize winnings on every hand",
          "To be unexploitable by opponents",
          "To always bluff at the right frequency",
          "To play as aggressively as possible"
        ],
        correctAnswer: 1,
        explanation: "GTO is a defensive strategy focused on being unexploitable."
      },
      {
        question: "In Rock-Paper-Scissors, what makes your strategy unexploitable?",
        options: [
          "Always play Rock",
          "Play what you feel",
          "Play each option 33.3% of the time",
          "Counter your opponent"
        ],
        correctAnswer: 2,
        explanation: "Playing each option with equal frequency prevents exploitation."
      },
      {
        question: "When should you deviate from GTO to exploitative play?",
        options: [
          "Never, GTO is always optimal",
          "When you identify profitable opponent weaknesses",
          "Only in tournaments",
          "When you're losing"
        ],
        correctAnswer: 1,
        explanation: "Exploit when you identify consistent leaks in opponents' play."
      }
    ],
    2: [
      {
        question: "Pot is $100, opponent bets $100. What equity do you need to call?",
        options: ["25%", "33%", "50%", "66%"],
        correctAnswer: 1,
        explanation: "100 / (100 + 100 + 100) = 33%"
      },
      {
        question: "How many combos of AK does villain have preflop?",
        options: ["4", "12", "16", "8"],
        correctAnswer: 2,
        explanation: "4 suited + 12 offsuit = 16 total combos"
      },
      {
        question: "You hold A♦ on a flush possible board. This is good for bluffing because:",
        options: [
          "It blocks the nuts",
          "It unblocks the nuts",
          "Aces are scary",
          "It improves your equity"
        ],
        correctAnswer: 0,
        explanation: "Holding the A♦ blocks villain's nut flush combos."
      }
    ],
    3: [
      {
        question: "What's your approximate RFI range from BTN (100bb)?",
        options: ["15%", "25%", "42%", "60%"],
        correctAnswer: 2,
        explanation: "BTN opens roughly 40-45% of hands."
      },
      {
        question: "At 30bb effective, how should you adjust RFI?",
        options: [
          "Tighter, fewer hands",
          "Same as 100bb",
          "Wider, more shoves IP",
          "Only premium hands"
        ],
        correctAnswer: 2,
        explanation: "Shallow stacks mean wider opening ranges and more all-in pressure."
      }
    ]
  }
};

// Export functions that return data based on current language
export const MODULES = (() => {
  const lang = getCurrentLanguage();
  return MODULES_DATA[lang] || MODULES_DATA.fr;
})();

export const MODULE_CONTENT = (() => {
  const lang = getCurrentLanguage();
  return MODULE_CONTENT_DATA[lang] || MODULE_CONTENT_DATA.fr;
})();

export const QUIZZES = (() => {
  const lang = getCurrentLanguage();
  return QUIZZES_DATA[lang] || QUIZZES_DATA.fr;
})();