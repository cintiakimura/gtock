import React from 'react';
import { motion } from 'framer-motion';
import { Play, Lock, CheckCircle2, Clock, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ModuleCard({ 
  module, 
  isCompleted, 
  isLocked, 
  progress = 0,
  viewMode = 'grid'
}) {
  const { id, title, description, duration, free } = module;

  if (viewMode === 'list') {
    // List View
    return (
      <Link 
        to={isLocked ? '#' : createPageUrl(`Module?id=${id}`)}
        className={`block ${isLocked ? 'cursor-not-allowed' : ''}`}
        onClick={e => isLocked && e.preventDefault()}
      >
        <motion.div
          whileHover={!isLocked ? { x: 4 } : {}}
          className={`
            flex items-center gap-4 p-4 rounded-xl border transition-all
            ${isLocked 
              ? 'bg-gray-900/40 border-gray-800 opacity-60' 
              : isCompleted 
                ? 'bg-gradient-to-r from-teal-900/20 to-gray-900 border-teal-500/30' 
                : 'bg-gradient-to-r from-gray-900 to-gray-950 border-white/10 hover:border-cyan-500/30'
            }
          `}
        >
          {/* Module Number/Status */}
          <div className={`
            w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold shrink-0
            ${isCompleted 
              ? 'bg-teal-500/20 text-teal-400' 
              : isLocked 
                ? 'bg-gray-800 text-gray-600' 
                : 'bg-cyan-500/10 text-cyan-400'
            }
          `}>
            {isCompleted ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : isLocked ? (
              <Lock className="w-4 h-4" />
            ) : (
              id
            )}
          </div>

          {/* Title & Description */}
          <div className="flex-1 min-w-0">
            <h3 className={`font-semibold mb-1 ${isLocked ? 'text-gray-500' : 'text-white'}`}>
              {title}
            </h3>
            <p className={`text-sm ${isLocked ? 'text-gray-600' : 'text-white/50'} line-clamp-1`}>
              {description}
            </p>
          </div>

          {/* Duration & Status */}
          <div className="flex items-center gap-4 shrink-0">
            <div className="flex items-center gap-1.5 text-white/40">
              <Clock className="w-3.5 h-3.5" />
              <span className="text-xs">{duration}</span>
            </div>
            
            {free && !isLocked && (
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 uppercase tracking-wider">
                Free
              </span>
            )}

            {!isLocked && (
              <span className={`text-sm font-medium ${isCompleted ? 'text-teal-400' : 'text-cyan-400'}`}>
                {isCompleted ? 'Review' : progress > 0 ? 'Continue' : 'Start'}
              </span>
            )}
          </div>
        </motion.div>
      </Link>
    );
  }

  // Grid View (default)
  return (
    <motion.div
      whileHover={{ y: isLocked ? 0 : -4 }}
      className={`
        module-card rounded-2xl border p-5
        ${isLocked 
          ? 'bg-gray-900/40 border-gray-800 opacity-60' 
          : isCompleted 
            ? 'bg-gradient-to-br from-teal-900/20 to-gray-900 border-teal-500/30' 
            : 'bg-gradient-to-br from-gray-900 to-gray-950 border-white/10 hover:border-cyan-500/30'
        }
      `}
    >
      <Link 
        to={isLocked ? '#' : createPageUrl(`Module?id=${id}`)}
        className={isLocked ? 'cursor-not-allowed' : 'cursor-pointer'}
        onClick={e => isLocked && e.preventDefault()}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`
              w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold
              ${isCompleted 
                ? 'bg-teal-500/20 text-teal-400' 
                : isLocked 
                  ? 'bg-gray-800 text-gray-600' 
                  : 'bg-cyan-500/10 text-cyan-400'
              }
            `}>
              {isCompleted ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : isLocked ? (
                <Lock className="w-4 h-4" />
              ) : (
                id
              )}
            </div>
            {free && !isLocked && (
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 uppercase tracking-wider">
                Free
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 text-white/40">
            <Clock className="w-3.5 h-3.5" />
            <span className="text-xs">{duration}</span>
          </div>
        </div>

        <h3 className={`font-semibold mb-2 ${isLocked ? 'text-gray-500' : 'text-white'}`}>
          {title}
        </h3>
        <p className={`text-sm ${isLocked ? 'text-gray-600' : 'text-white/50'}`}>
          {description}
        </p>

        {!isLocked && !isCompleted && (
          <div className="mt-4 flex items-center gap-2">
            <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-gradient-to-r from-cyan-500 to-teal-500"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <span className="text-xs text-white/40">{progress}%</span>
          </div>
        )}

        {!isLocked && (
          <motion.div 
            className="mt-4 flex items-center gap-2 text-cyan-400"
            whileHover={{ x: 5 }}
          >
            <Play className="w-4 h-4" />
            <span className="text-sm font-medium">
              {isCompleted ? 'Review' : progress > 0 ? 'Continue' : 'Start'}
            </span>
          </motion.div>
        )}
      </Link>
    </motion.div>
  );
}