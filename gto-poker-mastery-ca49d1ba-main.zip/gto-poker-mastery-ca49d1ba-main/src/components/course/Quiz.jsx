import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, XCircle, ArrowRight, Trophy } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Quiz({ 
  questions, 
  onComplete,
  moduleId 
}) {
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (index) => {
    if (isAnswered) return;
    setSelectedAnswer(index);
    setIsAnswered(true);
    if (index === questions[currentQ].correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQ < questions.length - 1) {
      setCurrentQ(currentQ + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      setShowResults(true);
    }
  };

  const handleComplete = () => {
    const percentage = Math.round((score / questions.length) * 100);
    onComplete(percentage);
  };

  if (showResults) {
    const percentage = Math.round((score / questions.length) * 100);
    const passed = percentage >= 70;

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-8 text-center"
      >
        <div className={`
          w-20 h-20 mx-auto mb-6 rounded-full flex items-center justify-center
          ${passed ? 'bg-teal-500/20' : 'bg-orange-500/20'}
        `}>
          <Trophy className={`w-10 h-10 ${passed ? 'text-teal-400' : 'text-orange-400'}`} />
        </div>

        <h3 className="text-2xl font-bold text-white mb-2">
          {passed ? 'Module Complete!' : 'Almost There!'}
        </h3>
        <p className="text-white/60 mb-6">
          You scored {score} out of {questions.length} ({percentage}%)
        </p>

        <div className="w-full max-w-xs mx-auto mb-8">
          <div className="h-3 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${percentage}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className={`h-full ${passed ? 'bg-gradient-to-r from-cyan-500 to-teal-500' : 'bg-orange-500'}`}
            />
          </div>
          <p className="text-xs text-white/40 mt-2">
            {passed ? 'Passing score: 70%' : 'You need 70% to pass'}
          </p>
        </div>

        <Button 
          onClick={handleComplete}
          className="bg-gradient-to-r from-cyan-500 to-teal-500 hover:opacity-90"
        >
          {passed ? 'Continue to Next Module' : 'Review Module'}
        </Button>
      </motion.div>
    );
  }

  const question = questions[currentQ];

  return (
    <div className="bg-gradient-to-br from-gray-900 to-gray-950 rounded-2xl border border-white/10 p-6">
      {/* Progress */}
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-white/50">
          Question {currentQ + 1} of {questions.length}
        </span>
        <div className="flex gap-1">
          {questions.map((_, i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full ${
                i < currentQ ? 'bg-teal-500' : 
                i === currentQ ? 'bg-cyan-400' : 'bg-white/20'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQ}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
        >
          <h3 className="text-xl font-semibold text-white mb-6">
            {question.question}
          </h3>

          <div className="space-y-3 mb-6">
            {question.options.map((option, index) => {
              const isCorrect = index === question.correctAnswer;
              const isSelected = selectedAnswer === index;
              
              return (
                <motion.button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  whileHover={!isAnswered ? { scale: 1.02 } : {}}
                  whileTap={!isAnswered ? { scale: 0.98 } : {}}
                  className={`
                    w-full p-4 rounded-xl text-left transition-all
                    ${!isAnswered ? 'bg-white/5 border border-white/10 hover:border-cyan-500/50 hover:bg-white/10' : ''}
                    ${isAnswered && isCorrect ? 'bg-teal-500/20 border border-teal-500/50' : ''}
                    ${isAnswered && isSelected && !isCorrect ? 'bg-red-500/20 border border-red-500/50' : ''}
                    ${isAnswered && !isSelected && !isCorrect ? 'bg-white/5 border border-white/10 opacity-50' : ''}
                  `}
                  disabled={isAnswered}
                >
                  <div className="flex items-center justify-between">
                    <span className={`${isAnswered && isCorrect ? 'text-teal-400' : isAnswered && isSelected ? 'text-red-400' : 'text-white'}`}>
                      {option}
                    </span>
                    {isAnswered && isCorrect && <CheckCircle2 className="w-5 h-5 text-teal-400" />}
                    {isAnswered && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-400" />}
                  </div>
                </motion.button>
              );
            })}
          </div>

          {/* Explanation */}
          {isAnswered && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/20 mb-6"
            >
              <p className="text-sm text-cyan-100">{question.explanation}</p>
            </motion.div>
          )}

          {/* Next Button */}
          {isAnswered && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <Button 
                onClick={handleNext}
                className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 hover:opacity-90"
              >
                {currentQ < questions.length - 1 ? (
                  <>Next Question <ArrowRight className="w-4 h-4 ml-2" /></>
                ) : (
                  'See Results'
                )}
              </Button>
            </motion.div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}