import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { prompt, context } = await req.json();

        const response = await fetch('https://api.x.ai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${Deno.env.get('GROK_API_KEY')}`
            },
            body: JSON.stringify({
                model: 'grok-beta',
                messages: [
                    {
                        role: 'system',
                        content: context || 'You are a helpful AI poker coach and GTO strategy expert.'
                    },
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.7
            })
        });

        const data = await response.json();

        if (!response.ok) {
            return Response.json({ error: data.error?.message || 'Grok API error' }, { status: response.status });
        }

        return Response.json({ 
            response: data.choices[0].message.content,
            model: data.model
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});