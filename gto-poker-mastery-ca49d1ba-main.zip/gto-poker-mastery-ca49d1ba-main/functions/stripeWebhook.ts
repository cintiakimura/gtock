import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import Stripe from 'npm:stripe@17.5.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

Deno.serve(async (req) => {
    try {
        // Get the raw body for signature verification
        const body = await req.text();
        const signature = req.headers.get('stripe-signature');

        // Initialize Base44 client BEFORE signature validation
        const base44 = createClientFromRequest(req);

        if (!signature) {
            return Response.json({ error: 'No signature provided' }, { status: 400 });
        }

        // Verify the webhook signature
        let event;
        try {
            event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
        } catch (err) {
            console.error('Webhook signature verification failed:', err.message);
            return Response.json({ error: 'Invalid signature' }, { status: 400 });
        }

        // Handle the event
        switch (event.type) {
            case 'checkout.session.completed': {
                const session = event.data.object;
                const customerEmail = session.customer_email || session.customer_details?.email;

                if (!customerEmail) {
                    console.error('No customer email found in checkout session');
                    break;
                }

                // Create or update subscription record
                const existingSubscriptions = await base44.asServiceRole.entities.Subscription.filter({
                    user_email: customerEmail
                });

                if (existingSubscriptions.length > 0) {
                    await base44.asServiceRole.entities.Subscription.update(existingSubscriptions[0].id, {
                        tier: 'pro',
                        status: 'active',
                        stripe_subscription_id: session.subscription,
                        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
                    });
                } else {
                    await base44.asServiceRole.entities.Subscription.create({
                        user_email: customerEmail,
                        tier: 'pro',
                        status: 'active',
                        stripe_subscription_id: session.subscription,
                        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
                    });
                }

                console.log('Subscription activated for:', customerEmail);
                break;
            }

            case 'customer.subscription.updated': {
                const subscription = event.data.object;
                const customer = await stripe.customers.retrieve(subscription.customer);
                const customerEmail = customer.email;

                if (!customerEmail) {
                    console.error('No customer email found');
                    break;
                }

                const existingSubscriptions = await base44.asServiceRole.entities.Subscription.filter({
                    user_email: customerEmail
                });

                if (existingSubscriptions.length > 0) {
                    await base44.asServiceRole.entities.Subscription.update(existingSubscriptions[0].id, {
                        status: subscription.status === 'active' ? 'active' : 'cancelled',
                        current_period_end: new Date(subscription.current_period_end * 1000).toISOString()
                    });
                }

                console.log('Subscription updated for:', customerEmail);
                break;
            }

            case 'customer.subscription.deleted': {
                const subscription = event.data.object;
                const customer = await stripe.customers.retrieve(subscription.customer);
                const customerEmail = customer.email;

                if (!customerEmail) {
                    console.error('No customer email found');
                    break;
                }

                const existingSubscriptions = await base44.asServiceRole.entities.Subscription.filter({
                    user_email: customerEmail
                });

                if (existingSubscriptions.length > 0) {
                    await base44.asServiceRole.entities.Subscription.update(existingSubscriptions[0].id, {
                        status: 'cancelled',
                        tier: 'free'
                    });
                }

                console.log('Subscription cancelled for:', customerEmail);
                break;
            }

            default:
                console.log('Unhandled event type:', event.type);
        }

        return Response.json({ received: true }, { status: 200 });
    } catch (error) {
        console.error('Webhook error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});