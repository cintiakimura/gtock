import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import Stripe from 'npm:stripe@17.5.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { priceId } = await req.json();

        if (!priceId) {
            return Response.json({ error: 'Price ID is required' }, { status: 400 });
        }

        // Fetch price to determine if it's recurring or one-time
        const price = await stripe.prices.retrieve(priceId);
        const mode = price.type === 'recurring' ? 'subscription' : 'payment';

        // Create checkout session
        const session = await stripe.checkout.sessions.create({
            mode: mode,
            customer_email: user.email,
            line_items: [
                {
                    price: priceId,
                    quantity: 1,
                },
            ],
            success_url: `https://gto-poker-mastery-ca49d1ba.base44.app/Settings?success=true`,
            cancel_url: `https://gto-poker-mastery-ca49d1ba.base44.app/Settings?cancelled=true`,
            metadata: {
                user_email: user.email,
            },
        });

        return Response.json({ url: session.url }, { status: 200 });
    } catch (error) {
        console.error('Checkout error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});